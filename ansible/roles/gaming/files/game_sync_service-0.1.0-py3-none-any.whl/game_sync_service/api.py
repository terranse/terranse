from __future__ import annotations

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from game_sync_service.config import Config
from game_sync_service.library import Library
from game_sync_service.models import serialize_game
from game_sync_service.store import MetadataStore


def create_app(config: Config, library: Library, store: MetadataStore) -> FastAPI:
    app = FastAPI(title="game-sync-service")

    @app.get("/games")
    async def games() -> dict:
        enrichments = store.get_all()
        return {
            "vm_hostname": config.hostname,
            "games": [
                serialize_game(game, enrichments.get(game.id))
                for game in library.snapshot()
            ],
        }

    art_root = config.cover_cache_dir
    for mount, directory in (
        ("/backdrops", art_root / "backdrops"),
        ("/logos", art_root / "logos"),
        ("/covers", art_root),
    ):
        directory.mkdir(parents=True, exist_ok=True)
        app.mount(mount, StaticFiles(directory=directory), name=mount.strip("/"))

    return app
