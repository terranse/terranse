from __future__ import annotations

import logging
import tomllib
from pathlib import Path

logger = logging.getLogger(__name__)


def load_overrides(path: Path) -> dict[str, dict]:
    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
    except FileNotFoundError:
        return {}
    except (OSError, tomllib.TOMLDecodeError):
        logger.warning("Unreadable overrides file: %s", path)
        return {}
    return {k: v for k, v in data.items() if isinstance(v, dict)}
