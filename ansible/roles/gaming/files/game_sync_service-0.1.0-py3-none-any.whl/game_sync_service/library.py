from __future__ import annotations

from game_sync_service.config import Config
from game_sync_service.lutris import read_lutris_games
from game_sync_service.models import Game
from game_sync_service.profiles import load_profiles, recommended_profile
from game_sync_service.retroarch import scan_retroarch_games


def _assign_sunshine_names(games: list[Game]) -> None:
    taken: set[str] = set()
    for game in games:
        if game.state != "installed":
            continue
        name = game.name if game.name not in taken else f"{game.name} ({game.source})"
        game.sunshine_app_name = name
        taken.add(name)


class Library:
    def __init__(self, config: Config):
        self._config = config
        self._games: list[Game] = []

    def scan(self) -> list[Game]:
        games = read_lutris_games(self._config) + scan_retroarch_games(self._config)
        games.sort(key=lambda g: (g.installed_at is None, -(g.installed_at or 0), g.name))
        _assign_sunshine_names(games)
        profiles = load_profiles(self._config.game_profiles_path)
        for game in games:
            game.gpu_profile_recommended = recommended_profile(game, profiles)
        self._games = games
        return games

    def snapshot(self) -> list[Game]:
        return list(self._games)
