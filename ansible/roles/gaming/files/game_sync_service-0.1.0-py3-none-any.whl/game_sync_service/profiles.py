from __future__ import annotations

import json
import logging
from pathlib import Path

from game_sync_service.models import Game

logger = logging.getLogger(__name__)


def load_profiles(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return None
    except (OSError, json.JSONDecodeError):
        logger.warning("Unreadable game profiles file: %s", path)
        return None


def recommended_profile(game: Game, profiles: dict | None) -> str | None:
    if profiles is None:
        return None
    table = profiles.get("profiles", {})
    if game.source == "retroarch":
        entry = table.get("emulator:retroarch")
    elif game.source == "steam" and game.service_appid:
        entry = table.get(f"steam:{game.service_appid}")
    else:
        entry = None
    if entry and entry.get("recommended_profile"):
        return entry["recommended_profile"]
    return profiles.get("defaults", {}).get("unknown_game")
