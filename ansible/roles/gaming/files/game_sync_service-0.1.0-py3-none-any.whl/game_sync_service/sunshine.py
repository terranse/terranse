from __future__ import annotations

import json
import logging
import os
import subprocess
import tempfile
from pathlib import Path

from game_sync_service.config import Config
from game_sync_service.models import Game

logger = logging.getLogger(__name__)


def _load_json(path: Path, default):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def _game_entry(game: Game, config: Config) -> dict | None:
    if game.source == "retroarch":
        if not game.rom_path or not game.emulator:
            return None
        core = config.retroarch_core_dir / f"{game.emulator}_libretro.so"
        cmd = f'{config.retroarch_cmd} -L {core} "{game.rom_path}"'
    else:
        if game.lutris_id is None:
            return None
        cmd = f"{config.lutris_cmd} lutris:rungameid/{game.lutris_id}"
    return {"name": game.sunshine_app_name, "cmd": cmd, "image-path": "", "auto-detach": True}


def _atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(content)
        os.replace(tmp, path)
    except BaseException:
        os.unlink(tmp)
        raise


def sync_sunshine_apps(games: list[Game], config: Config) -> bool:
    apps_path = config.sunshine_apps_path
    sidecar = config.data_dir / "sunshine-managed.json"
    current = _load_json(apps_path, {"env": {}, "apps": []})
    managed = set(_load_json(sidecar, []))

    kept = [a for a in current.get("apps", []) if a.get("name") not in managed]
    kept_names = {a.get("name") for a in kept}

    entries = []
    for game in games:
        if game.state != "installed" or not game.sunshine_app_name:
            continue
        if game.sunshine_app_name in kept_names:
            continue  # never shadow a user-defined entry
        entry = _game_entry(game, config)
        if entry:
            entries.append(entry)

    desired = {**current, "apps": kept + entries}
    serialized = json.dumps(desired, indent=2)
    if _load_json(apps_path, None) == desired:
        return False

    _atomic_write(apps_path, serialized)
    config.data_dir.mkdir(parents=True, exist_ok=True)
    _atomic_write(sidecar, json.dumps(sorted(e["name"] for e in entries)))
    if config.sunshine_reload_cmd:
        logger.info("apps.json changed, running reload_cmd")
        subprocess.run(config.sunshine_reload_cmd, shell=True, check=False)
    return True
