from __future__ import annotations

import json
import sqlite3
import threading
from datetime import UTC, datetime
from pathlib import Path

from game_sync_service.models import Enrichment

_SCHEMA = """
CREATE TABLE IF NOT EXISTS enrichment (
    game_id TEXT PRIMARY KEY,
    igdb_id INTEGER,
    sgdb_id INTEGER,
    description TEXT,
    genres TEXT NOT NULL DEFAULT '[]',
    release_year INTEGER,
    rating REAL,
    has_cover INTEGER NOT NULL DEFAULT 0,
    has_backdrop INTEGER NOT NULL DEFAULT 0,
    has_logo INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending',
    updated_at TEXT
);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT);
"""

_COLS = (
    "game_id, igdb_id, sgdb_id, description, genres, release_year, rating,"
    " has_cover, has_backdrop, has_logo"
)


def _row_to_enrichment(row: sqlite3.Row) -> Enrichment:
    return Enrichment(
        game_id=row["game_id"],
        igdb_id=row["igdb_id"],
        sgdb_id=row["sgdb_id"],
        description=row["description"],
        genres=json.loads(row["genres"]),
        release_year=row["release_year"],
        rating=row["rating"],
        has_cover=bool(row["has_cover"]),
        has_backdrop=bool(row["has_backdrop"]),
        has_logo=bool(row["has_logo"]),
    )


class MetadataStore:
    def __init__(self, db_path: Path):
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock, self._conn:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(_SCHEMA)

    def get(self, game_id: str) -> Enrichment | None:
        with self._lock:
            row = self._conn.execute(
                f"SELECT {_COLS} FROM enrichment WHERE game_id = ?", (game_id,)
            ).fetchone()
        return _row_to_enrichment(row) if row else None

    def get_all(self) -> dict[str, Enrichment]:
        with self._lock:
            rows = self._conn.execute(f"SELECT {_COLS} FROM enrichment").fetchall()
        return {row["game_id"]: _row_to_enrichment(row) for row in rows}

    def status(self, game_id: str) -> str | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT status FROM enrichment WHERE game_id = ?", (game_id,)
            ).fetchone()
        return row["status"] if row else None

    def upsert(self, enrichment: Enrichment, status: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                f"""INSERT OR REPLACE INTO enrichment ({_COLS}, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    enrichment.game_id, enrichment.igdb_id, enrichment.sgdb_id,
                    enrichment.description, json.dumps(enrichment.genres),
                    enrichment.release_year, enrichment.rating,
                    int(enrichment.has_cover), int(enrichment.has_backdrop),
                    int(enrichment.has_logo), status,
                    datetime.now(tz=UTC).isoformat(),
                ),
            )

    def mark_failed(self, game_id: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO enrichment (game_id, status) VALUES (?, 'pending')",
                (game_id,),
            )
            self._conn.execute(
                "UPDATE enrichment SET status = 'failed' WHERE game_id = ?", (game_id,)
            )

    def kv_get(self, key: str) -> str | None:
        with self._lock:
            row = self._conn.execute("SELECT value FROM kv WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else None

    def kv_set(self, key: str, value: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)", (key, value))

    def close(self) -> None:
        self._conn.close()
