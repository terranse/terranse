from __future__ import annotations

import shutil
import sqlite3
import tempfile
from pathlib import Path

from game_sync_service.config import Config
from game_sync_service.models import Game

SERVICE_TO_SOURCE = {"steam": "steam", "egs": "epic", "gog": "gog"}

_WANTED = [
    "id", "name", "slug", "runner", "platform",
    "installed", "installed_at", "year", "service", "service_id",
]


def _source_enabled(source: str, config: Config) -> bool:
    return {
        "steam": config.steam_enabled,
        "epic": config.epic_enabled,
        "gog": config.gog_enabled,
    }.get(source, True)


def read_lutris_games(config: Config) -> list[Game]:
    if not config.lutris_db_path.exists():
        return []
    # Lutris may hold the db open mid-write; read a private copy.
    with tempfile.TemporaryDirectory(prefix="game-sync-pga") as tmp:
        copy = Path(tmp) / "pga.db"
        shutil.copy(config.lutris_db_path, copy)
        conn = sqlite3.connect(f"file:{copy}?mode=ro", uri=True)
        try:
            conn.row_factory = sqlite3.Row
            available = {r[1] for r in conn.execute("PRAGMA table_info(games)")}
            select = ", ".join(c for c in _WANTED if c in available)
            rows = conn.execute(f"SELECT {select} FROM games").fetchall()
        finally:
            conn.close()

    games: list[Game] = []
    for row in rows:
        r = dict(row)
        name, slug = r.get("name"), r.get("slug")
        if not name or not slug:
            continue
        source = SERVICE_TO_SOURCE.get(r.get("service") or "", "lutris")
        if not _source_enabled(source, config):
            continue
        service_id = r.get("service_id")
        game_id = f"{source}-{service_id}" if source != "lutris" and service_id else f"lutris-{slug}"
        platform = r.get("platform")
        games.append(
            Game(
                id=game_id,
                name=name,
                source=source,
                platform=platform.lower() if platform else None,
                state="installed" if r.get("installed") else "not_installed",
                installed_at=r.get("installed_at"),
                slug=slug,
                service_appid=service_id if source == "steam" else None,
                release_year_hint=r.get("year"),
                lutris_id=r.get("id"),
            )
        )
    return games
