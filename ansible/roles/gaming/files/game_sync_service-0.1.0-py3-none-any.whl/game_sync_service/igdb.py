from __future__ import annotations

import asyncio
import json
import time
from datetime import UTC, datetime

import httpx

from game_sync_service.store import MetadataStore

TOKEN_URL = "https://id.twitch.tv/oauth2/token"
API = "https://api.igdb.com/v4"
GAME_FIELDS = "name,summary,genres.name,first_release_date,aggregated_rating"
_MIN_INTERVAL = 0.25  # IGDB allows 4 req/s


def _chunks(items: list, size: int):
    for i in range(0, len(items), size):
        yield items[i : i + size]


def _release_year(game: dict) -> int | None:
    ts = game.get("first_release_date")
    return datetime.fromtimestamp(ts, tz=UTC).year if ts else None


def _pick_by_year(candidates: list[dict], year: int | None) -> dict | None:
    if not candidates:
        return None
    if year is not None:
        for game in candidates:
            got = _release_year(game)
            if got is not None and abs(got - year) <= 1:
                return game
    return candidates[0]


class IGDBClient:
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        store: MetadataStore,
        http: httpx.AsyncClient | None = None,
    ):
        self._client_id = client_id
        self._client_secret = client_secret
        self._store = store
        self._http = http or httpx.AsyncClient(timeout=30)
        self._throttle_lock = asyncio.Lock()
        self._last_call = 0.0

    async def aclose(self) -> None:
        await self._http.aclose()

    async def _get_token(self, force: bool = False) -> str:
        if not force:
            cached = self._store.kv_get("igdb_token")
            if cached:
                data = json.loads(cached)
                if data["expires_at"] > time.time() + 60:
                    return data["token"]
        resp = await self._http.post(
            TOKEN_URL,
            params={
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "grant_type": "client_credentials",
            },
        )
        resp.raise_for_status()
        payload = resp.json()
        self._store.kv_set(
            "igdb_token",
            json.dumps(
                {"token": payload["access_token"], "expires_at": time.time() + payload["expires_in"]}
            ),
        )
        return payload["access_token"]

    async def _wait_turn(self) -> None:
        async with self._throttle_lock:
            wait = self._last_call + _MIN_INTERVAL - time.monotonic()
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_call = time.monotonic()

    async def _post(self, endpoint: str, body: str) -> list[dict]:
        token = await self._get_token()
        for attempt in (1, 2):
            await self._wait_turn()
            resp = await self._http.post(
                f"{API}/{endpoint}",
                content=body,
                headers={"Client-ID": self._client_id, "Authorization": f"Bearer {token}"},
            )
            if resp.status_code == 401 and attempt == 1:
                token = await self._get_token(force=True)
                continue
            if resp.status_code == 429 and attempt == 1:
                await asyncio.sleep(1)
                continue
            resp.raise_for_status()
            return resp.json()
        raise RuntimeError("unreachable")

    async def game_by_id(self, igdb_id: int) -> dict | None:
        rows = await self._post("games", f"fields {GAME_FIELDS}; where id = ({igdb_id});")
        return rows[0] if rows else None

    async def games_by_steam_appids(self, appids: list[str]) -> dict[str, dict]:
        result: dict[str, dict] = {}
        for chunk in _chunks(appids, 100):
            uids = ",".join(f'"{a}"' for a in chunk)
            rows = await self._post(
                "external_games",
                f"fields game,uid; where uid = ({uids}) & external_game_source = 1; limit 500;",
            )
            uid_to_game = {r["uid"]: r["game"] for r in rows if r.get("game")}
            if not uid_to_game:
                continue
            ids = ",".join(str(gid) for gid in sorted(set(uid_to_game.values())))
            games = await self._post(
                "games", f"fields {GAME_FIELDS}; where id = ({ids}); limit 500;"
            )
            by_id = {g["id"]: g for g in games}
            for uid, gid in uid_to_game.items():
                if gid in by_id:
                    result[uid] = by_id[gid]
        return result

    async def search_games_multi(
        self, queries: list[tuple[str, int | None]]
    ) -> list[dict | None]:
        results: list[dict | None] = []
        for chunk in _chunks(queries, 10):
            body = "".join(
                f'query games "q{i}" {{ fields {GAME_FIELDS};'
                f' search "{name.replace(chr(34), "")}"; limit 5; }};\n'
                for i, (name, _year) in enumerate(chunk)
            )
            rows = await self._post("multiquery", body)
            by_name = {r.get("name"): r.get("result", []) for r in rows}
            for i, (_name, year) in enumerate(chunk):
                results.append(_pick_by_year(by_name.get(f"q{i}", []), year))
        return results
