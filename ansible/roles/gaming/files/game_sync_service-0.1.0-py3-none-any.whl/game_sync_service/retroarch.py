from __future__ import annotations

import re

from game_sync_service.config import Config
from game_sync_service.models import Game

# system dir name -> (libretro core, accepted extensions)
SYSTEM_CORES: dict[str, tuple[str, set[str]]] = {
    "nes": ("nestopia", {".nes"}),
    "snes": ("snes9x", {".sfc", ".smc"}),
    "n64": ("mupen64plus_next", {".z64", ".n64", ".v64"}),
    "gb": ("mgba", {".gb", ".gbc"}),
    "gba": ("mgba", {".gba"}),
    "nds": ("desmume", {".nds"}),
    "psx": ("beetle_psx_hw", {".cue", ".chd", ".pbp"}),
    "ps2": ("pcsx2", {".iso", ".chd"}),
    "psp": ("ppsspp", {".iso", ".cso"}),
    "gamecube": ("dolphin", {".iso", ".rvz", ".gcm"}),
    "wii": ("dolphin", {".iso", ".rvz", ".wbfs"}),
}

_TAG_RE = re.compile(r"[\(\[][^\)\]]*[\)\]]")


def clean_rom_name(stem: str) -> str:
    name = _TAG_RE.sub("", stem).replace("_", " ")
    return re.sub(r"\s+", " ", name).strip()


def _slugify(text: str) -> str:
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]", "-", text.lower())).strip("-")


def scan_retroarch_games(config: Config) -> list[Game]:
    root = config.retroarch_rom_path
    if not config.retroarch_enabled or root is None or not root.is_dir():
        return []
    games: list[Game] = []
    for system_dir in sorted(root.iterdir()):
        entry = SYSTEM_CORES.get(system_dir.name)
        if not entry or not system_dir.is_dir():
            continue
        core, extensions = entry
        for rom in sorted(system_dir.iterdir()):
            if rom.suffix.lower() not in extensions:
                continue
            name = clean_rom_name(rom.stem)
            games.append(
                Game(
                    id=f"retroarch-{system_dir.name}-{_slugify(name)}",
                    name=name,
                    source="retroarch",
                    platform=system_dir.name,
                    state="installed",
                    emulator=core,
                    slug=_slugify(name),
                    rom_path=str(rom),
                )
            )
    return games
