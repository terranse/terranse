from __future__ import annotations

import configparser
import socket
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Config:
    port: int
    hostname: str
    lutris_db_path: Path
    lutris_cmd: str
    lutris_coverart_dir: Path | None
    sunshine_apps_path: Path
    sunshine_reload_cmd: str
    cover_cache_dir: Path
    game_profiles_path: Path
    data_dir: Path
    steam_enabled: bool
    epic_enabled: bool
    gog_enabled: bool
    retroarch_enabled: bool
    retroarch_rom_path: Path | None
    retroarch_cmd: str
    retroarch_core_dir: Path
    igdb_client_id: str
    igdb_client_secret: str
    steamgriddb_api_key: str

    @property
    def igdb_enabled(self) -> bool:
        return bool(self.igdb_client_id and self.igdb_client_secret)

    @property
    def sgdb_enabled(self) -> bool:
        return bool(self.steamgriddb_api_key)


def _opt_path(value: str) -> Path | None:
    return Path(value) if value else None


def load_config(path: str | Path) -> Config:
    parser = configparser.ConfigParser()
    if not parser.read(path):
        raise FileNotFoundError(path)
    return Config(
        port=parser.getint("general", "port", fallback=9766),
        hostname=parser.get("general", "hostname", fallback=socket.gethostname()),
        lutris_db_path=Path(parser.get("lutris", "db_path")),
        lutris_cmd=parser.get("lutris", "lutris_cmd", fallback="lutris"),
        lutris_coverart_dir=_opt_path(parser.get("lutris", "coverart_dir", fallback="")),
        sunshine_apps_path=Path(parser.get("sunshine", "apps_path")),
        sunshine_reload_cmd=parser.get("sunshine", "reload_cmd", fallback=""),
        cover_cache_dir=Path(parser.get("storage", "cover_cache_dir")),
        game_profiles_path=Path(parser.get("storage", "game_profiles_path")),
        data_dir=Path(parser.get("storage", "data_dir", fallback="/var/lib/game-sync")),
        steam_enabled=parser.getboolean("stores", "steam_enabled", fallback=True),
        epic_enabled=parser.getboolean("stores", "epic_enabled", fallback=True),
        gog_enabled=parser.getboolean("stores", "gog_enabled", fallback=True),
        retroarch_enabled=parser.getboolean("stores", "retroarch_enabled", fallback=False),
        retroarch_rom_path=_opt_path(parser.get("stores", "retroarch_rom_path", fallback="")),
        retroarch_cmd=parser.get(
            "stores", "retroarch_cmd", fallback="flatpak run org.libretro.RetroArch"
        ),
        retroarch_core_dir=Path(
            parser.get(
                "stores", "retroarch_core_dir", fallback="/usr/lib/x86_64-linux-gnu/libretro"
            )
        ),
        igdb_client_id=parser.get("metadata", "igdb_client_id", fallback=""),
        igdb_client_secret=parser.get("metadata", "igdb_client_secret", fallback=""),
        steamgriddb_api_key=parser.get("metadata", "steamgriddb_api_key", fallback=""),
    )
