from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Game:
    id: str
    name: str
    source: str  # steam|epic|gog|retroarch|lutris
    platform: str | None
    state: str  # installed|installing|not_installed|queued|update_available
    sunshine_app_name: str | None = None
    gpu_profile_recommended: str | None = None
    emulator: str | None = None
    family_shared: bool = False
    # internal hints, not serialized
    installed_at: int | None = None
    slug: str | None = None
    service_appid: str | None = None
    release_year_hint: int | None = None
    rom_path: str | None = None
    lutris_id: int | None = None


@dataclass
class Enrichment:
    game_id: str
    igdb_id: int | None = None
    sgdb_id: int | None = None
    description: str | None = None
    genres: list[str] = field(default_factory=list)
    release_year: int | None = None
    rating: float | None = None
    has_cover: bool = False
    has_backdrop: bool = False
    has_logo: bool = False


def serialize_game(game: Game, enrichment: Enrichment | None = None) -> dict:
    enr = enrichment or Enrichment(game_id=game.id)
    return {
        "id": game.id,
        "name": game.name,
        "source": game.source,
        "platform": game.platform,
        "cover_url": f"/covers/{game.id}.jpg" if enr.has_cover else None,
        "state": game.state,
        "sunshine_app_name": game.sunshine_app_name,
        "gpu_profile_recommended": game.gpu_profile_recommended,
        "emulator": game.emulator,
        "family_shared": game.family_shared,
        "description": enr.description,
        "genres": list(enr.genres),
        "release_year": enr.release_year,
        "rating": enr.rating,
        "backdrop_url": f"/backdrops/{game.id}.jpg" if enr.has_backdrop else None,
        "logo_url": f"/logos/{game.id}.png" if enr.has_logo else None,
    }
