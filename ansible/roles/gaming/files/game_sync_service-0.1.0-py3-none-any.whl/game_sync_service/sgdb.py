from __future__ import annotations

import os
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import quote

import httpx

API = "https://www.steamgriddb.com/api/v2"


class SGDBClient:
    def __init__(self, api_key: str, http: httpx.AsyncClient | None = None):
        self._http = http or httpx.AsyncClient(timeout=30, follow_redirects=True)
        self._headers = {"Authorization": f"Bearer {api_key}"}

    async def aclose(self) -> None:
        await self._http.aclose()

    async def _get_data(self, path: str, **params):
        resp = await self._http.get(f"{API}{path}", headers=self._headers, params=params)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        payload = resp.json()
        return payload.get("data") if payload.get("success") else None

    async def game_id_by_steam_appid(self, appid: str) -> int | None:
        data = await self._get_data(f"/games/steam/{appid}")
        return data["id"] if data else None

    async def search(self, name: str, year: int | None = None) -> int | None:
        data = await self._get_data(f"/search/autocomplete/{quote(name)}")
        if not data:
            return None
        if year is not None:
            for entry in data:
                ts = entry.get("release_date")
                if ts and abs(datetime.fromtimestamp(ts, tz=UTC).year - year) <= 1:
                    return entry["id"]
        return data[0]["id"]

    async def _first_url(self, path: str, **params) -> str | None:
        data = await self._get_data(path, **params)
        return data[0]["url"] if data else None

    async def best_hero(self, game_id: int) -> str | None:
        return await self._first_url(f"/heroes/game/{game_id}")

    async def best_logo(self, game_id: int) -> str | None:
        return await self._first_url(f"/logos/game/{game_id}")

    async def best_grid(self, game_id: int) -> str | None:
        return await self._first_url(f"/grids/game/{game_id}", dimensions="600x900")

    async def download(self, url: str, dest: Path) -> None:
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_suffix(dest.suffix + ".part")
        try:
            async with self._http.stream("GET", url) as resp:
                resp.raise_for_status()
                with open(tmp, "wb") as f:
                    async for chunk in resp.aiter_bytes():
                        f.write(chunk)
            os.replace(tmp, dest)
        except BaseException:
            tmp.unlink(missing_ok=True)
            raise
