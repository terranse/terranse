from __future__ import annotations

import threading
from collections.abc import Callable
from pathlib import Path

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer


class _Handler(FileSystemEventHandler):
    def __init__(self, prefix: str, on_hit: Callable[[], None]):
        self._prefix = prefix
        self._on_hit = on_hit

    def on_any_event(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        paths = [event.src_path, getattr(event, "dest_path", "") or ""]
        if any(str(p).startswith(self._prefix) for p in paths):
            self._on_hit()


class DbWatcher:
    def __init__(self, db_path: Path, callback: Callable[[], None], debounce: float = 1.0):
        self._db_path = db_path
        self._callback = callback
        self._debounce = debounce
        self._observer = Observer()
        self._timer: threading.Timer | None = None
        self._lock = threading.Lock()
        self._stopped = False

    def _schedule(self) -> None:
        with self._lock:
            if self._stopped:
                return
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(self._debounce, self._callback)
            self._timer.daemon = True
            self._timer.start()

    def start(self) -> None:
        handler = _Handler(str(self._db_path), self._schedule)
        self._observer.schedule(handler, str(self._db_path.parent))
        self._observer.start()

    def stop(self) -> None:
        with self._lock:
            self._stopped = True
            if self._timer is not None:
                self._timer.cancel()
        self._observer.stop()
        self._observer.join(timeout=5)
