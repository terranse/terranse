from __future__ import annotations

import asyncio
import logging
import shutil
from datetime import UTC, datetime

from game_sync_service.config import Config
from game_sync_service.igdb import IGDBClient
from game_sync_service.models import Enrichment, Game
from game_sync_service.overrides import load_overrides
from game_sync_service.sgdb import SGDBClient
from game_sync_service.store import MetadataStore

logger = logging.getLogger(__name__)

_RETRYABLE = (None, "pending", "failed")


class EnrichmentPipeline:
    def __init__(
        self,
        config: Config,
        store: MetadataStore,
        igdb: IGDBClient | None,
        sgdb: SGDBClient | None,
    ):
        self._config = config
        self._store = store
        self._igdb = igdb
        self._sgdb = sgdb
        self._run_lock = asyncio.Lock()

    def _needs_enrichment(self, game: Game, overrides: dict[str, dict]) -> bool:
        status = self._store.status(game.id)
        if status in _RETRYABLE:
            return True
        override = overrides.get(game.id)
        if override:
            row = self._store.get(game.id)
            if override.get("igdb_id") and override["igdb_id"] != row.igdb_id:
                return True
            if override.get("sgdb_id") and override["sgdb_id"] != row.sgdb_id:
                return True
        return False

    async def enrich_library(self, games: list[Game]) -> None:
        if self._igdb is None and self._sgdb is None:
            logger.info("No enrichment clients configured; skipping enrichment entirely")
            return
        async with self._run_lock:
            overrides = load_overrides(self._config.data_dir / "overrides.toml")
            pending = [g for g in games if self._needs_enrichment(g, overrides)]
            if not pending:
                return
            logger.info("Enriching %d game(s)", len(pending))
            igdb_matches = await self._igdb_text_pass(pending, overrides)
            for game in pending:
                try:
                    await self._enrich_one(
                        game, igdb_matches.get(game.id), overrides.get(game.id, {})
                    )
                except Exception:
                    logger.exception("Enrichment failed for %s", game.id)
                    self._store.mark_failed(game.id)

    async def _igdb_text_pass(
        self, games: list[Game], overrides: dict[str, dict]
    ) -> dict[str, dict]:
        if self._igdb is None:
            return {}
        matches: dict[str, dict] = {}
        by_appid: list[Game] = []
        by_search: list[Game] = []
        try:
            for game in games:
                override_id = overrides.get(game.id, {}).get("igdb_id")
                if override_id:
                    found = await self._igdb.game_by_id(override_id)
                    if found:
                        matches[game.id] = found
                elif game.source == "steam" and game.service_appid:
                    by_appid.append(game)
                else:
                    by_search.append(game)
            if by_appid:
                found_by_appid = await self._igdb.games_by_steam_appids(
                    [g.service_appid for g in by_appid]
                )
                for game in by_appid:
                    if game.service_appid in found_by_appid:
                        matches[game.id] = found_by_appid[game.service_appid]
            if by_search:
                results = await self._igdb.search_games_multi(
                    [(g.name, g.release_year_hint) for g in by_search]
                )
                for game, result in zip(by_search, results):
                    if result:
                        matches[game.id] = result
        except Exception:
            logger.exception("IGDB text pass failed; continuing without text facts")
        return matches

    async def _match_sgdb(self, game: Game, override: dict) -> int | None:
        if override.get("sgdb_id"):
            return override["sgdb_id"]
        if game.source == "steam" and game.service_appid:
            found = await self._sgdb.game_id_by_steam_appid(game.service_appid)
            if found:
                return found
        return await self._sgdb.search(game.name, year=game.release_year_hint)

    async def _enrich_one(self, game: Game, igdb_game: dict | None, override: dict) -> None:
        enr = self._store.get(game.id) or Enrichment(game_id=game.id)
        if igdb_game:
            enr.igdb_id = igdb_game["id"]
            enr.description = igdb_game.get("summary")
            enr.genres = [g["name"] for g in igdb_game.get("genres", [])]
            ts = igdb_game.get("first_release_date")
            enr.release_year = datetime.fromtimestamp(ts, tz=UTC).year if ts else None
            enr.rating = igdb_game.get("aggregated_rating")

        art_root = self._config.cover_cache_dir
        cover = art_root / f"{game.id}.jpg"
        backdrop = art_root / "backdrops" / f"{game.id}.jpg"
        logo = art_root / "logos" / f"{game.id}.png"

        lutris_cover = self._lutris_cover(game)
        if lutris_cover and not cover.exists():
            cover.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(lutris_cover, cover)

        if self._sgdb is not None:
            sgdb_id = await self._match_sgdb(game, override)
            if sgdb_id:
                enr.sgdb_id = sgdb_id
                if not backdrop.exists():
                    url = await self._sgdb.best_hero(sgdb_id)
                    if url:
                        await self._sgdb.download(url, backdrop)
                if not logo.exists():
                    url = await self._sgdb.best_logo(sgdb_id)
                    if url:
                        await self._sgdb.download(url, logo)
                if not cover.exists():
                    url = await self._sgdb.best_grid(sgdb_id)
                    if url:
                        await self._sgdb.download(url, cover)

        enr.has_cover = cover.exists()
        enr.has_backdrop = backdrop.exists()
        enr.has_logo = logo.exists()
        status = "done" if (enr.igdb_id or enr.sgdb_id) else "unmatched"
        self._store.upsert(enr, status=status)

    def _lutris_cover(self, game: Game):
        coverart_dir = self._config.lutris_coverart_dir
        if coverart_dir is None or not game.slug:
            return None
        candidate = coverart_dir / f"{game.slug}.jpg"
        return candidate if candidate.exists() else None
