"""Launch Epic games with legendary, umu-launcher and a pinned GE-Proton."""
from __future__ import annotations

import argparse
import configparser
import json
import os
import re
import shutil
import subprocess
import sys
import zlib
from pathlib import Path

from game_sync_service.config import load_config
from game_sync_service.legendary import legendary_base
from game_sync_service.steam_client import (
    _DEFAULT_CONFIG,
    _display_env,
    processes_with_env,
    supervise,
)


_BASELAYER = "GAMESCOPECTRL_BASELAYER_APPID"
_SYNC_TIMEOUT = 60
_HEROIC = "com.heroicgameslauncher.hgl"
# A game Heroic starts has to be shown too, not only Heroic itself.
_HEROIC_WINDOWS = rf"^({re.escape(_HEROIC)}|steam_app_.*)$"


def prefix_for(config, app_name: str) -> Path:
    return Path(config.epic_prefix_dir) / app_name


def gamescope_id(app_name: str) -> int:
    """A stable id for gamescope to focus by, clear of Steam's own app ids."""
    return 0x40000000 | (zlib.crc32(app_name.encode()) & 0x0FFFFFFF)


def epic_game_running(config) -> bool:
    return bool(config.epic_proton_dir) and bool(
        processes_with_env(f"PROTONPATH={config.epic_proton_dir}")
    )


def launch_command(config, app_name: str) -> list[str]:
    return legendary_base(config) + ["launch", app_name, "--no-wine", "--wrapper", "umu-run"]


def launch_env(config, app_name: str, base: dict[str, str]) -> dict[str, str]:
    env = dict(base)
    # Inside gamescope, not beside it: with sway's socket visible the game would
    # open as a sway window instead.
    env.pop("WAYLAND_DISPLAY", None)
    env.update(
        WINEPREFIX=str(prefix_for(config, app_name)),
        PROTONPATH=config.epic_proton_dir,
        STORE="egs",
        GAMEID=f"umu-{gamescope_id(app_name)}",
    )
    return env


def _x11(env: dict[str, str], *args: str) -> str:
    try:
        return subprocess.run(
            args, env=env, capture_output=True, text=True, timeout=5, check=False
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def baselayer_with(game_id: int, current: str) -> str | None:
    """The focus list that puts this game first, or None if it already is."""
    ids = [int(i) for i in re.findall(r"\d+", current.partition("=")[2])]
    if ids[:1] == [game_id]:
        return None
    return ",".join(str(i) for i in [game_id, *(i for i in ids if i != game_id)])


class GamescopeFocus:
    """Puts a game that Steam didn't start on screen.

    In its Steam mode gamescope shows only windows tagged with an app id, picking
    the first id Steam listed. Proton tags Steam's own launches, not ours, so
    without this the game runs unseen behind Big Picture. Repeated while the game
    runs, because it can open new windows and Steam can rewrite the list.
    """

    def __init__(self, app_name: str, env: dict[str, str], windows: str | None = None):
        self._id = gamescope_id(app_name)
        self._env = env
        self._windows = windows or f"steam_app_{self._id}"

    def __call__(self) -> None:
        windows = _x11(
            self._env, "xdotool", "search", "--onlyvisible", "--class", self._windows
        ).split()
        for window in windows:
            # Asked each time: X reuses the id of a helper window that has closed,
            # so remembering which ids are done would skip the game's own window.
            if str(self._id) not in _x11(self._env, "xprop", "-id", window, "-notype", "STEAM_GAME"):
                _x11(
                    self._env, "xprop", "-id", window,
                    "-f", "STEAM_GAME", "32c", "-set", "STEAM_GAME", str(self._id),
                )
        if not windows:
            return
        current = _x11(self._env, "xprop", "-root", "-notype", _BASELAYER)
        wanted = baselayer_with(self._id, current)
        if wanted:
            _x11(self._env, "xprop", "-root", "-f", _BASELAYER, "32c", "-set", _BASELAYER, wanted)


def set_save_prefix(config, app_name: str) -> None:
    """Tell legendary where this game's saves are. Not its `.env` section, which
    would also change the environment the game launches with."""
    path = Path(config.legendary_config_dir) / "config.ini"
    # Read and written the way legendary does, which keeps its comments.
    ini = configparser.ConfigParser(comment_prefixes="/", allow_no_value=True, interpolation=None)
    ini.optionxform = str
    ini.read(path)
    wanted = str(prefix_for(config, app_name) / "pfx")
    if ini.get(app_name, "wine_prefix", fallback=None) == wanted:
        return
    if not ini.has_section(app_name):
        ini.add_section(app_name)
    ini.set(app_name, "wine_prefix", wanted)
    with path.open("w") as f:
        ini.write(f)


def sync_command(config, app_name: str, direction: str) -> list[str]:
    skip = "--skip-upload" if direction == "download" else "--skip-download"
    # Without --accept-path, -y skips a game whose save folder was never confirmed.
    return legendary_base(config) + ["-y", "sync-saves", app_name, "--accept-path", skip]


def download_saves(config, app_name: str) -> None:
    """Before the game starts: a new prefix with no saves must not end up newer
    than the real ones in the cloud. Playing offline beats not playing, so a
    failure here doesn't stop the launch."""
    try:
        subprocess.run(
            sync_command(config, app_name, "download"),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=_SYNC_TIMEOUT,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        print(f"could not download saves: {exc}", file=sys.stderr)


def upload_saves(config, app_name: str) -> None:
    """After the game ends. In its own session, because the stream should end now
    and Sunshine stops whatever is left of the app when it does."""
    try:
        subprocess.Popen(
            sync_command(config, app_name, "upload"),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as exc:
        print(f"could not upload saves: {exc}", file=sys.stderr)


def launch(app_name: str, config) -> int:
    prefix = prefix_for(config, app_name)
    prefix.mkdir(parents=True, exist_ok=True)
    # Every process of this game has it, from the wrapper to the game itself.
    env_entry = f"GAMEID=umu-{gamescope_id(app_name)}"
    display = _display_env()

    def start() -> None:
        set_save_prefix(config, app_name)
        download_saves(config, app_name)
        # Returns at once; the game keeps running under the wrapper.
        subprocess.run(
            launch_command(config, app_name),
            env=launch_env(config, app_name, display),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

    try:
        return supervise(
            env_entry,
            start,
            lambda: bool(processes_with_env(env_entry)),
            tick=GamescopeFocus(app_name, display),
        )
    finally:
        upload_saves(config, app_name)


def prepare_heroic(config, home: Path) -> None:
    """Make Heroic use the library legendary already has.

    With its own config directory Heroic would ask for a second login and could
    download a second copy of a game. It also keeps its own record of who is signed
    in, and asks a question at first run that a remote can't answer.
    """
    heroic = home / ".var/app" / _HEROIC / "config/heroic"
    shared = Path(config.legendary_config_dir)
    link = heroic / "legendaryConfig/legendary"
    link.parent.mkdir(parents=True, exist_ok=True)
    if link.is_dir() and not link.is_symlink():
        shutil.rmtree(link)
    if not link.is_symlink():
        link.symlink_to(shared)

    store = heroic / "store/config.json"
    try:
        settings = json.loads(store.read_text())
    except (OSError, ValueError):
        settings = {}
    general = settings.setdefault("settings", {})
    general["defaultInstallPath"] = config.epic_install_dir
    general["analyticsOptIn"] = False
    try:
        user = json.loads((shared / "user.json").read_text())
        settings["userInfo"] = {
            "account_id": user["account_id"],
            "displayName": user["displayName"],
        }
    except (OSError, ValueError, KeyError):
        settings.pop("userInfo", None)
    store.parent.mkdir(parents=True, exist_ok=True)
    store.write_text(json.dumps(settings, indent=2))


def open_heroic(config) -> int:
    display = _display_env()
    prepare_heroic(config, Path(display.get("HOME", str(Path.home()))))
    env = dict(display)
    env.pop("WAYLAND_DISPLAY", None)
    env_entry = f"FLATPAK_ID={_HEROIC}"

    def start() -> None:
        # Blocks for as long as Heroic runs, so it can't be waited on here.
        subprocess.Popen(
            ["flatpak", "run", _HEROIC],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    return supervise(
        env_entry,
        start,
        lambda: bool(processes_with_env(env_entry)),
        tick=GamescopeFocus(_HEROIC, env, _HEROIC_WINDOWS),
    )


def main() -> None:
    parser = argparse.ArgumentParser(prog="game-sync-epic")
    parser.add_argument("action", choices=["launch", "heroic"])
    parser.add_argument("app_name", nargs="?")
    args = parser.parse_args()
    if args.action == "launch" and not args.app_name:
        parser.error("launch needs an app name")
    config = load_config(os.environ.get("GAME_SYNC_CONFIG", _DEFAULT_CONFIG))
    if args.action == "heroic":
        sys.exit(open_heroic(config))
    sys.exit(launch(args.app_name, config))


if __name__ == "__main__":
    main()
