from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Game:
    id: str
    name: str
    source: str  # steam|epic|gog|retroarch|lutris|port|local
    platform: str | None
    state: str  # installed|installing|not_installed|queued|update_available
    sunshine_app_name: str | None = None
    gpu_profile_recommended: str | None = None
    emulator: str | None = None
    family_shared: bool = False
    # internal hints, not serialized
    installed_at: int | None = None
    slug: str | None = None
    service_appid: str | None = None
    release_year_hint: int | None = None
    rom_path: str | None = None
    lutris_id: int | None = None
    # For matching art when the source isn't Steam but the game is on it.
    steam_appid: str | None = None
    has_installer: bool = False
    art_urls: dict[str, list[str]] = field(default_factory=dict)
    # A ROM with a homescreen card; the others are for ES-DE.
    showcase: bool = False

    @property
    def steam_lookup_id(self) -> str | None:
        return self.service_appid if self.source == "steam" else self.steam_appid


# A job is "running" while it still owns a child process or a queue slot.
# These are exactly the states a service restart invalidates.
RUNNING_JOB_STATES = ("queued", "downloading", "verifying")

INTERRUPTED_REASON = "interrupted by a game-sync restart; start the install again"


@dataclass
class InstallJob:
    job_id: str
    game_id: str
    state: str  # queued|downloading|verifying|done|failed|cancelled|interrupted
    percent: float | None = None
    bytes_done: int | None = None
    bytes_total: int | None = None
    eta: str | None = None
    reason: str | None = None
    created_at: str = ""


def job_cancellable(job: InstallJob) -> bool:
    return not (job.game_id.startswith("steam-") and job.state != "queued")


def serialize_job(job: InstallJob) -> dict:
    return {
        "cancellable": job_cancellable(job),
        "job_id": job.job_id,
        "game_id": job.game_id,
        "state": job.state,
        "percent": job.percent,
        "bytes_done": job.bytes_done,
        "bytes_total": job.bytes_total,
        "eta": job.eta,
        "reason": job.reason,
    }


@dataclass
class Enrichment:
    game_id: str
    igdb_id: int | None = None
    sgdb_id: int | None = None
    description: str | None = None
    genres: list[str] = field(default_factory=list)
    release_year: int | None = None
    rating: float | None = None
    # Critics and players together, with its votes. `rating` is critics alone,
    # which few old games have enough of to rank by.
    total_rating: float | None = None
    total_rating_count: int | None = None
    has_cover: bool = False
    has_backdrop: bool = False
    has_logo: bool = False


def serialize_game(
    game: Game,
    enrichment: Enrichment | None = None,
    job: InstallJob | None = None,
    *,
    last_played: float | None = None,
    first_seen: float | None = None,
) -> dict:
    enr = enrichment or Enrichment(game_id=game.id)
    return {
        # Present on every game so a client can render install progress from
        # /games alone, without a second round trip per card.
        "install": serialize_job(job) if job else None,
        "id": game.id,
        "name": game.name,
        "source": game.source,
        "platform": game.platform,
        "cover_url": f"/covers/{game.id}.jpg" if enr.has_cover else None,
        "state": game.state,
        "sunshine_app_name": game.sunshine_app_name,
        "gpu_profile_recommended": game.gpu_profile_recommended,
        "emulator": game.emulator,
        "family_shared": game.family_shared,
        "description": enr.description,
        "genres": list(enr.genres),
        "release_year": enr.release_year,
        "rating": enr.rating,
        "backdrop_url": f"/backdrops/{game.id}.jpg" if enr.has_backdrop else None,
        "logo_url": f"/logos/{game.id}.png" if enr.has_logo else None,
        "last_played": last_played,
        # When the game counts as new from: first seen, or installed, if later. A
        # game already known at the baseline scan has only its install date (epoch
        # seconds from every scanner; None for ROMs and for games not installed).
        # 0 means neither: there is no real date to report.
        "first_seen": max(first_seen or 0, game.installed_at or 0) or None,
    }
