"""Box art for retro games from the keyless libretro thumbnail collection."""
from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from urllib.parse import quote

import httpx

from game_sync_service.models import Game

logger = logging.getLogger(__name__)

BASE = "https://thumbnails.libretro.com"

LIBRETRO_SYSTEMS: dict[str, str] = {
    "nes": "Nintendo - Nintendo Entertainment System",
    "snes": "Nintendo - Super Nintendo Entertainment System",
    "n64": "Nintendo - Nintendo 64",
    "genesis": "Sega - Mega Drive - Genesis",
    "megadrive": "Sega - Mega Drive - Genesis",
    "mastersystem": "Sega - Master System - Mark III",
    "gamegear": "Sega - Game Gear",
    "gb": "Nintendo - Game Boy",
    "gbc": "Nintendo - Game Boy Color",
    "gba": "Nintendo - Game Boy Advance",
    "nds": "Nintendo - Nintendo DS",
    "psx": "Sony - PlayStation",
    "ps2": "Sony - PlayStation 2",
    "psp": "Sony - PlayStation Portable",
    "gamecube": "Nintendo - GameCube",
    "gc": "Nintendo - GameCube",
    "wii": "Nintendo - Wii",
}

_REGIONS = ("USA", "Europe", "Japan", "World")
_RESERVED = re.compile(r'[&*/:\\`<>?|"]')


def _safe(name: str) -> str:
    return _RESERVED.sub("_", name)


def candidates(platform: str, rom_stem: str, clean_name: str) -> list[str]:
    """Thumbnail file names to try, best first: the ROM's own name, then the clean name by region."""
    names = [rom_stem, *(f"{clean_name} ({r})" for r in _REGIONS), clean_name]
    out: list[str] = []
    for n in names:
        f = f"{_safe(n)}.png"
        if f not in out:
            out.append(f)
    return out


class LibretroUnavailable(Exception):
    """The art host failed (network error or 5xx), as opposed to having no match."""


class LibretroArt:
    def __init__(self, http: httpx.AsyncClient | None = None):
        self._http = http or httpx.AsyncClient(timeout=20, follow_redirects=True)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def fetch_cover(self, game: Game, dest: Path) -> bool:
        """True if a cover was saved, False on a true miss; raises LibretroUnavailable on errors."""
        from game_sync_service.retroarch import clean_rom_name

        system = LIBRETRO_SYSTEMS.get((game.platform or "").lower())
        if not system or not game.rom_path:
            return False
        stem = Path(game.rom_path).stem
        for name in candidates(game.platform, stem, clean_rom_name(stem)):
            url = f"{BASE}/{quote(system, safe='')}/Named_Boxarts/{quote(name, safe='')}"
            try:
                if await self._download(url, dest):
                    return True
            except Exception as exc:
                raise LibretroUnavailable(str(exc)) from exc
        return False

    async def _download(self, url: str, dest: Path) -> bool:
        tmp = dest.with_suffix(dest.suffix + ".part")
        try:
            async with self._http.stream("GET", url) as resp:
                if resp.status_code == 404:
                    return False
                resp.raise_for_status()
                dest.parent.mkdir(parents=True, exist_ok=True)
                with open(tmp, "wb") as f:
                    async for chunk in resp.aiter_bytes():
                        f.write(chunk)
            os.replace(tmp, dest)
            return True
        except BaseException:
            tmp.unlink(missing_ok=True)
            raise
