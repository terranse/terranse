from __future__ import annotations

import json
import sqlite3
import threading
from datetime import UTC, datetime
from pathlib import Path

from game_sync_service.models import (
    INTERRUPTED_REASON,
    RUNNING_JOB_STATES,
    Enrichment,
    InstallJob,
)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS enrichment (
    game_id TEXT PRIMARY KEY,
    igdb_id INTEGER,
    sgdb_id INTEGER,
    description TEXT,
    genres TEXT NOT NULL DEFAULT '[]',
    release_year INTEGER,
    rating REAL,
    has_cover INTEGER NOT NULL DEFAULT 0,
    has_backdrop INTEGER NOT NULL DEFAULT 0,
    has_logo INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending',
    updated_at TEXT
);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS install_job (
    job_id TEXT PRIMARY KEY,
    game_id TEXT NOT NULL,
    state TEXT NOT NULL,
    percent REAL,
    bytes_done INTEGER,
    bytes_total INTEGER,
    eta TEXT,
    reason TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS install_job_game ON install_job (game_id);
"""

_COLS = (
    "game_id, igdb_id, sgdb_id, description, genres, release_year, rating,"
    " has_cover, has_backdrop, has_logo"
)


_JOB_COLS = (
    "job_id, game_id, state, percent, bytes_done, bytes_total, eta, reason, created_at"
)


def _row_to_job(row: sqlite3.Row) -> InstallJob:
    return InstallJob(
        job_id=row["job_id"],
        game_id=row["game_id"],
        state=row["state"],
        percent=row["percent"],
        bytes_done=row["bytes_done"],
        bytes_total=row["bytes_total"],
        eta=row["eta"],
        reason=row["reason"],
        created_at=row["created_at"],
    )


def _row_to_enrichment(row: sqlite3.Row) -> Enrichment:
    return Enrichment(
        game_id=row["game_id"],
        igdb_id=row["igdb_id"],
        sgdb_id=row["sgdb_id"],
        description=row["description"],
        genres=json.loads(row["genres"]),
        release_year=row["release_year"],
        rating=row["rating"],
        has_cover=bool(row["has_cover"]),
        has_backdrop=bool(row["has_backdrop"]),
        has_logo=bool(row["has_logo"]),
    )


class MetadataStore:
    def __init__(self, db_path: Path):
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock, self._conn:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(_SCHEMA)

    def get(self, game_id: str) -> Enrichment | None:
        with self._lock:
            row = self._conn.execute(
                f"SELECT {_COLS} FROM enrichment WHERE game_id = ?", (game_id,)
            ).fetchone()
        return _row_to_enrichment(row) if row else None

    def get_all(self) -> dict[str, Enrichment]:
        with self._lock:
            rows = self._conn.execute(f"SELECT {_COLS} FROM enrichment").fetchall()
        return {row["game_id"]: _row_to_enrichment(row) for row in rows}

    def status(self, game_id: str) -> str | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT status FROM enrichment WHERE game_id = ?", (game_id,)
            ).fetchone()
        return row["status"] if row else None

    def upsert(self, enrichment: Enrichment, status: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                f"""INSERT OR REPLACE INTO enrichment ({_COLS}, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    enrichment.game_id, enrichment.igdb_id, enrichment.sgdb_id,
                    enrichment.description, json.dumps(enrichment.genres),
                    enrichment.release_year, enrichment.rating,
                    int(enrichment.has_cover), int(enrichment.has_backdrop),
                    int(enrichment.has_logo), status,
                    datetime.now(tz=UTC).isoformat(),
                ),
            )

    def mark_failed(self, game_id: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO enrichment (game_id, status) VALUES (?, 'pending')",
                (game_id,),
            )
            self._conn.execute(
                "UPDATE enrichment SET status = 'failed' WHERE game_id = ?", (game_id,)
            )

    def kv_get(self, key: str) -> str | None:
        with self._lock:
            row = self._conn.execute("SELECT value FROM kv WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else None

    def kv_set(self, key: str, value: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)", (key, value))

    # --- install jobs -----------------------------------------------------

    def upsert_job(self, job: InstallJob) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT OR REPLACE INTO install_job
                   (job_id, game_id, state, percent, bytes_done, bytes_total,
                    eta, reason, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    job.job_id, job.game_id, job.state, job.percent,
                    job.bytes_done, job.bytes_total, job.eta, job.reason,
                    job.created_at,
                ),
            )

    def get_job(self, job_id: str) -> InstallJob | None:
        with self._lock:
            row = self._conn.execute(
                f"SELECT {_JOB_COLS} FROM install_job WHERE job_id = ?", (job_id,)
            ).fetchone()
        return _row_to_job(row) if row else None

    def list_jobs(self) -> list[InstallJob]:
        with self._lock:
            rows = self._conn.execute(
                f"SELECT {_JOB_COLS} FROM install_job ORDER BY created_at, job_id"
            ).fetchall()
        return [_row_to_job(r) for r in rows]

    def active_job_for_game(self, game_id: str) -> InstallJob | None:
        """The job currently occupying this game, if any.

        Finished jobs are kept for history, so "is this game busy" has to ask
        about state rather than mere existence.
        """
        placeholders = ", ".join("?" * len(RUNNING_JOB_STATES))
        with self._lock:
            row = self._conn.execute(
                f"SELECT {_JOB_COLS} FROM install_job"
                f" WHERE game_id = ? AND state IN ({placeholders})"
                " ORDER BY created_at DESC LIMIT 1",
                (game_id, *RUNNING_JOB_STATES),
            ).fetchone()
        return _row_to_job(row) if row else None

    def mark_running_jobs_interrupted(self) -> int:
        """Reconcile jobs orphaned by a restart.

        A job left mid-flight has no child process any more — its installer
        died with the service. Leaving it "downloading" would strand the UI on
        a progress bar that can never move again.
        """
        placeholders = ", ".join("?" * len(RUNNING_JOB_STATES))
        with self._lock, self._conn:
            cur = self._conn.execute(
                f"UPDATE install_job SET state = 'interrupted', reason = ?"
                f" WHERE state IN ({placeholders})",
                (INTERRUPTED_REASON, *RUNNING_JOB_STATES),
            )
            return cur.rowcount

    def close(self) -> None:
        self._conn.close()
