from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from game_sync_service.config import Config
from game_sync_service.models import Game

logger = logging.getLogger(__name__)

STREAM_PORTS = (47998, 47999, 48000)


def _load_json(path: Path, default):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def _bin(name: str) -> str:
    # Beside this interpreter: only the main entry point is on PATH.
    return str(Path(sys.executable).parent / name)


def _supervised_entry(game: Game, launch: str) -> dict:
    return {
        "name": game.sunshine_app_name,
        "cmd": launch,
        "image-path": "",
        # The command blocks for the life of the game, which is what ends the
        # stream when the game exits. wait-all off, or a lingering wineserver holds
        # the stream open. A long exit-timeout gives Proton time to shut down.
        "auto-detach": False,
        "wait-all": False,
        "exit-timeout": 30,
    }


def can_launch(game: Game) -> bool:
    """Whether Sunshine can be given an entry for this game."""
    if game.source == "retroarch":
        return bool(game.rom_path and game.emulator)
    if game.source in ("steam", "epic"):
        return bool(game.service_appid)
    return game.lutris_id is not None


def _game_entry(game: Game, config: Config) -> dict | None:
    if not can_launch(game):
        return None
    if game.source == "steam":
        return _supervised_entry(game, f"{_bin('game-sync-steam')} launch {game.service_appid}")
    if game.source == "epic":
        return _supervised_entry(game, f"{_bin('game-sync-epic')} launch {game.service_appid}")
    if game.source == "retroarch":
        core = config.retroarch_core_dir / f"{game.emulator}_libretro.so"
        cmd = f'{config.retroarch_cmd} -L {core} "{game.rom_path}"'
    else:
        cmd = f"{config.lutris_cmd} lutris:rungameid/{game.lutris_id}"
    return {"name": game.sunshine_app_name, "cmd": cmd, "image-path": "", "auto-detach": True}


def _atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(content)
        os.replace(tmp, path)
    except BaseException:
        os.unlink(tmp)
        raise


def sync_sunshine_apps(games: list[Game], config: Config) -> bool:
    apps_path = config.sunshine_apps_path
    sidecar = config.data_dir / "sunshine-managed.json"
    current = _load_json(apps_path, {"env": {}, "apps": []})
    managed = set(_load_json(sidecar, []))

    kept = [a for a in current.get("apps", []) if a.get("name") not in managed]
    kept_names = {a.get("name") for a in kept}

    entries = []
    for game in games:
        if game.state != "installed" or not game.sunshine_app_name:
            continue
        if game.sunshine_app_name in kept_names:
            continue  # never shadow a user-defined entry
        entry = _game_entry(game, config)
        if entry:
            entries.append(entry)

    desired = {**current, "apps": kept + entries}
    serialized = json.dumps(desired, indent=2)
    if _load_json(apps_path, None) == desired:
        return False

    _atomic_write(apps_path, serialized)
    config.data_dir.mkdir(parents=True, exist_ok=True)
    _atomic_write(sidecar, json.dumps(sorted(e["name"] for e in entries)))
    return True


# The store's own library screen, per source. The first is the session itself.
_STORE_APPS = (("steam", "Steam Big Picture"), ("epic", "Heroic"))


def store_apps(config: Config) -> list[dict]:
    """Store clients a stream can open, kept out of the games list."""
    current = _load_json(config.sunshine_apps_path, {"apps": []})
    names = {a.get("name") for a in current.get("apps", [])}
    return [
        {"source": source, "sunshine_app_name": name}
        for source, name in _STORE_APPS
        if name in names
    ]


def stream_live(proc_net: Path = Path("/proc/net")) -> bool:
    """Whether a client is streaming: Sunshine binds these only for that long."""
    for name in ("udp", "udp6"):
        try:
            lines = (proc_net / name).read_text().splitlines()[1:]
        except OSError:
            continue
        for line in lines:
            fields = line.split()
            if len(fields) > 1 and int(fields[1].rsplit(":", 1)[1], 16) in STREAM_PORTS:
                return True
    return False


class SunshineReloader:
    """Restart Sunshine for a changed apps.json once nobody would notice.

    Sunshine only reads the file at startup, and restarting it ends any stream.
    A running game counts as busy even with no client connected: its launch
    command is Sunshine's child, so the restart would take the game down with it.
    The flag is a file so a game-sync restart doesn't forget a pending reload.
    """

    def __init__(self, config: Config, busy, quiet_seconds: float = 60.0, clock=time.monotonic):
        self._cmd = config.sunshine_reload_cmd
        self._flag = config.data_dir / "sunshine-reload-pending"
        self._busy = busy
        self._quiet_seconds = quiet_seconds
        self._clock = clock
        self._last_busy = clock()

    def mark(self) -> None:
        if self._cmd:
            self._flag.touch()

    def tick(self) -> None:
        if self._busy():
            self._last_busy = self._clock()
            return
        if not self._flag.exists() or self._clock() - self._last_busy < self._quiet_seconds:
            return
        logger.info("apps.json changed and Sunshine is idle, reloading")
        if subprocess.run(self._cmd, shell=True, check=False).returncode == 0:
            self._flag.unlink(missing_ok=True)
