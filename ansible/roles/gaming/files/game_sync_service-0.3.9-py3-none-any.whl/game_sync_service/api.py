from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles

from game_sync_service.config import Config
from game_sync_service.library import Library
from game_sync_service.models import serialize_game, serialize_job
from game_sync_service.store import MetadataStore
from game_sync_service.sunshine import store_apps


def create_app(
    config: Config,
    library: Library,
    store: MetadataStore,
    installs=None,
) -> FastAPI:
    app = FastAPI(title="game-sync-service")

    def _require_installs():
        if installs is None:
            raise HTTPException(status_code=503, detail="installs are not enabled")
        return installs

    @app.get("/games")
    async def games() -> dict:
        enrichments = store.get_all()
        snapshot = library.snapshot()
        # One lookup for the whole payload rather than per game: the active
        # job set is small and this runs on every poll.
        active = (
            {j.game_id: j for j in installs.all_jobs()
             if j.state in ("queued", "downloading", "verifying")}
            if installs is not None
            else {}
        )
        return {
            "vm_hostname": config.hostname,
            "store_apps": store_apps(config),
            "games": [
                serialize_game(game, enrichments.get(game.id), active.get(game.id))
                for game in snapshot
            ],
        }

    @app.post("/install/{game_id}", status_code=202)
    async def start_install(game_id: str) -> dict:
        manager = _require_installs()
        try:
            job = await manager.enqueue(game_id)
        except LookupError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {"job_id": job.job_id}

    @app.get("/installs")
    async def list_installs() -> dict:
        manager = _require_installs()
        return {"jobs": [serialize_job(j) for j in manager.all_jobs()]}

    @app.get("/install/{job_id}")
    async def get_install(job_id: str) -> dict:
        manager = _require_installs()
        job = manager.status(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="no such job")
        return serialize_job(job)

    @app.delete("/install/{job_id}", status_code=204)
    async def cancel_install(job_id: str) -> Response:
        manager = _require_installs()
        if not await manager.cancel(job_id):
            raise HTTPException(status_code=404, detail="no cancellable job")
        return Response(status_code=204)

    art_root = config.cover_cache_dir
    for mount, directory in (
        ("/backdrops", art_root / "backdrops"),
        ("/logos", art_root / "logos"),
        ("/covers", art_root),
    ):
        directory.mkdir(parents=True, exist_ok=True)
        app.mount(mount, StaticFiles(directory=directory), name=mount.strip("/"))

    return app
