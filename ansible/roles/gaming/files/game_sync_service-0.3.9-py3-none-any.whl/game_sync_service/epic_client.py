"""Launch Epic games with legendary, umu-launcher and a pinned GE-Proton."""
from __future__ import annotations

import argparse
import configparser
import json
import os
import re
import shutil
import subprocess
import sys
import zlib
from pathlib import Path

from game_sync_service.config import load_config
from game_sync_service.legendary import legendary_base
from game_sync_service.steam_client import (
    _DEFAULT_CONFIG,
    _display_env,
    processes_with_env,
    supervise,
)


_BASELAYER = "GAMESCOPECTRL_BASELAYER_APPID"
_SYNC_TIMEOUT = 60
_SHARE_EVERY_TICKS = 3
_HEROIC = "com.heroicgameslauncher.hgl"
# A game Heroic starts has to be shown too, not only Heroic itself.
_HEROIC_WINDOWS = rf"^({re.escape(_HEROIC)}|steam_app_.*)$"


def prefix_for(config, app_name: str) -> Path:
    return Path(config.epic_prefix_dir) / app_name


def gamescope_id(app_name: str) -> int:
    """A stable id for gamescope to focus by, clear of Steam's own app ids."""
    return 0x40000000 | (zlib.crc32(app_name.encode()) & 0x0FFFFFFF)


def epic_game_running(config) -> bool:
    return bool(config.epic_proton_dir) and bool(
        processes_with_env(f"PROTONPATH={config.epic_proton_dir}")
    )


def launch_command(config, app_name: str) -> list[str]:
    return legendary_base(config) + ["launch", app_name, "--no-wine", "--wrapper", "umu-run"]


def launch_env(config, app_name: str, base: dict[str, str]) -> dict[str, str]:
    env = dict(base)
    # Inside gamescope, not beside it: with sway's socket visible the game would
    # open as a sway window instead.
    env.pop("WAYLAND_DISPLAY", None)
    env.update(
        WINEPREFIX=str(prefix_for(config, app_name)),
        PROTONPATH=config.epic_proton_dir,
        STORE="egs",
        GAMEID=f"umu-{gamescope_id(app_name)}",
    )
    return env


def _x11(env: dict[str, str], *args: str) -> str:
    try:
        return subprocess.run(
            args, env=env, capture_output=True, text=True, timeout=5, check=False
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def baselayer_with(game_id: int, current: str) -> str | None:
    """The focus list that puts this game first, or None if it already is."""
    ids = [int(i) for i in re.findall(r"\d+", current.partition("=")[2])]
    if ids[:1] == [game_id]:
        return None
    return ",".join(str(i) for i in [game_id, *(i for i in ids if i != game_id)])


class GamescopeFocus:
    """Puts a game that Steam didn't start on screen.

    In its Steam mode gamescope shows only windows tagged with an app id, picking
    the first id Steam listed. Proton tags Steam's own launches, not ours, so
    without this the game runs unseen behind Big Picture. Repeated while the game
    runs, because it can open new windows and Steam can rewrite the list.
    """

    def __init__(self, app_name: str, env: dict[str, str], windows: str | None = None):
        self._id = gamescope_id(app_name)
        self._env = env
        self._windows = windows or f"steam_app_{self._id}"

    def __call__(self) -> None:
        windows = _x11(
            self._env, "xdotool", "search", "--onlyvisible", "--class", self._windows
        ).split()
        for window in windows:
            # Asked each time: X reuses the id of a helper window that has closed,
            # so remembering which ids are done would skip the game's own window.
            if str(self._id) not in _x11(self._env, "xprop", "-id", window, "-notype", "STEAM_GAME"):
                _x11(
                    self._env, "xprop", "-id", window,
                    "-f", "STEAM_GAME", "32c", "-set", "STEAM_GAME", str(self._id),
                )
        if not windows:
            return
        current = _x11(self._env, "xprop", "-root", "-notype", _BASELAYER)
        wanted = baselayer_with(self._id, current)
        if wanted:
            _x11(self._env, "xprop", "-root", "-f", _BASELAYER, "32c", "-set", _BASELAYER, wanted)


def set_save_prefixes(config, app_names: list[str]) -> None:
    """Tell legendary where these games' saves are. Not their `.env` sections, which
    would also change the environment a game launches with."""
    path = Path(config.legendary_config_dir) / "config.ini"
    # Read and written the way legendary does, which keeps its comments.
    ini = configparser.ConfigParser(comment_prefixes="/", allow_no_value=True, interpolation=None)
    ini.optionxform = str
    ini.read(path)
    changed = False
    for app_name in app_names:
        wanted = str(prefix_for(config, app_name) / "pfx")
        if ini.get(app_name, "wine_prefix", fallback=None) == wanted:
            continue
        if not ini.has_section(app_name):
            ini.add_section(app_name)
        ini.set(app_name, "wine_prefix", wanted)
        changed = True
    if changed:
        with path.open("w") as f:
            ini.write(f)


def sync_command(config, app_name: str | None, direction: str) -> list[str]:
    """For one game, or every installed game with no name."""
    skip = "--skip-upload" if direction == "download" else "--skip-download"
    games = [app_name] if app_name else []
    # Without --accept-path, -y skips a game whose save folder was never confirmed.
    return legendary_base(config) + ["-y", "sync-saves", *games, "--accept-path", skip]


def download_saves(config, app_name: str | None = None) -> None:
    """Before a game can start: a new prefix with no saves must not end up newer
    than the real ones in the cloud. Playing offline beats not playing, so a
    failure here doesn't stop the launch."""
    try:
        subprocess.run(
            sync_command(config, app_name, "download"),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=_SYNC_TIMEOUT,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        print(f"could not download saves: {exc}", file=sys.stderr)


def upload_saves(config, app_name: str | None = None) -> None:
    """After a game ends. In its own session, because the stream should end now
    and Sunshine stops whatever is left of the app when it does."""
    try:
        subprocess.Popen(
            sync_command(config, app_name, "upload"),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as exc:
        print(f"could not upload saves: {exc}", file=sys.stderr)


def launch(app_name: str, config) -> int:
    prefix = prefix_for(config, app_name)
    prefix.mkdir(parents=True, exist_ok=True)
    # Every process of this game has it, from the wrapper to the game itself.
    env_entry = f"GAMEID=umu-{gamescope_id(app_name)}"
    display = _display_env()

    def start() -> None:
        set_save_prefixes(config, [app_name])
        download_saves(config, app_name)
        # Returns at once; the game keeps running under the wrapper.
        subprocess.run(
            launch_command(config, app_name),
            env=launch_env(config, app_name, display),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

    try:
        return supervise(
            env_entry,
            start,
            lambda: bool(processes_with_env(env_entry)),
            tick=GamescopeFocus(app_name, display),
        )
    finally:
        upload_saves(config, app_name)


def _heroic_dir(home: Path) -> Path:
    return home / ".var/app" / _HEROIC / "config/heroic"


def _owned_apps(config) -> list[str]:
    return sorted(p.stem for p in (Path(config.legendary_config_dir) / "metadata").glob("*.json"))


def _installed_apps(config) -> list[str]:
    try:
        installed = json.loads((Path(config.legendary_config_dir) / "installed.json").read_text())
    except (OSError, ValueError):
        return []
    return list(installed)


def _heroic_runner(config) -> dict[str, str]:
    return {
        "bin": str(Path(config.epic_proton_dir) / "proton"),
        "name": Path(config.epic_proton_dir).name,
        "type": "proton",
    }


def _redirect_prefix(path: Path, prefix: Path) -> None:
    """Send a path Heroic has settled on to the shared prefix.

    Heroic's install dialog writes its own choice and keeps that in memory until it
    restarts, so correcting its settings isn't enough for a game played straight
    after installing. A folder with anything in it is left alone: it could hold saves.
    """
    if path.is_symlink() or path == prefix:
        return
    try:
        if path.exists():
            path.rmdir()
        path.parent.mkdir(parents=True, exist_ok=True)
        prefix.mkdir(parents=True, exist_ok=True)
        path.symlink_to(prefix)
    except OSError as exc:
        print(f"could not share prefix {path}: {exc}", file=sys.stderr)


def share_prefixes_with_heroic(config, heroic: Path) -> None:
    """Have Heroic run each game in the prefix a Home Player launch uses, so both
    see the same saves.

    Written for every owned game, because a game installed from inside Heroic is
    played before this could run again. The same Proton too: Proton upgrades a
    prefix to its own version, and two taking turns can break it.
    """
    runner = _heroic_runner(config)
    games = heroic / "GamesConfig"
    games.mkdir(parents=True, exist_ok=True)
    for app_name in _owned_apps(config):
        path = games / f"{app_name}.json"
        try:
            current = json.loads(path.read_text())
        except (OSError, ValueError):
            current = {}
        chosen = current.get(app_name, {}).get("winePrefix")
        if chosen:
            _redirect_prefix(Path(chosen), prefix_for(config, app_name))
        wanted = {
            **current,
            app_name: {
                **current.get(app_name, {}),
                "winePrefix": str(prefix_for(config, app_name)),
                "wineVersion": runner,
            },
            "version": "v0",
            "explicit": True,
        }
        if wanted != current:
            path.write_text(json.dumps(wanted, indent=2))


class HeroicWatch:
    """What has to keep happening while Heroic is open."""

    def __init__(self, config, heroic: Path, focus, every: int = _SHARE_EVERY_TICKS):
        self._config = config
        self._heroic = heroic
        self._focus = focus
        self._every = every
        self._ticks = 0

    def __call__(self) -> None:
        self._focus()
        self._ticks += 1
        if self._ticks % self._every == 0:
            share_prefixes_with_heroic(self._config, self._heroic)


def prepare_heroic(config, home: Path) -> None:
    """Make Heroic use the library legendary already has.

    With its own config directory Heroic would ask for a second login and could
    download a second copy of a game. It also keeps its own record of who is signed
    in, and asks a question at first run that a remote can't answer.
    """
    heroic = _heroic_dir(home)
    shared = Path(config.legendary_config_dir)
    link = heroic / "legendaryConfig/legendary"
    link.parent.mkdir(parents=True, exist_ok=True)
    if link.is_dir() and not link.is_symlink():
        shutil.rmtree(link)
    if not link.is_symlink():
        link.symlink_to(shared)

    store = heroic / "store/config.json"
    try:
        settings = json.loads(store.read_text())
    except (OSError, ValueError):
        settings = {}
    general = settings.setdefault("settings", {})
    general["defaultInstallPath"] = config.epic_install_dir
    general["analyticsOptIn"] = False
    general["wineVersion"] = _heroic_runner(config)
    # The install dialog only offers what's in this folder.
    tools = heroic / "tools/proton"
    tools.mkdir(parents=True, exist_ok=True)
    ours = tools / Path(config.epic_proton_dir).name
    if not ours.is_symlink():
        ours.symlink_to(config.epic_proton_dir)
    try:
        user = json.loads((shared / "user.json").read_text())
        settings["userInfo"] = {
            "account_id": user["account_id"],
            "displayName": user["displayName"],
        }
    except (OSError, ValueError, KeyError):
        settings.pop("userInfo", None)
    store.parent.mkdir(parents=True, exist_ok=True)
    store.write_text(json.dumps(settings, indent=2))
    share_prefixes_with_heroic(config, heroic)


def open_heroic(config) -> int:
    display = _display_env()
    home = Path(display.get("HOME", str(Path.home())))
    prepare_heroic(config, home)
    env = dict(display)
    env.pop("WAYLAND_DISPLAY", None)
    env_entry = f"FLATPAK_ID={_HEROIC}"

    def start() -> None:
        set_save_prefixes(config, _installed_apps(config))
        download_saves(config)
        # Blocks for as long as Heroic runs, so it can't be waited on here.
        subprocess.Popen(
            ["flatpak", "run", _HEROIC],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    try:
        return supervise(
            env_entry,
            start,
            lambda: bool(processes_with_env(env_entry)),
            tick=HeroicWatch(config, _heroic_dir(home), GamescopeFocus(_HEROIC, env, _HEROIC_WINDOWS)),
        )
    finally:
        # Includes anything installed and played while Heroic was open.
        set_save_prefixes(config, _installed_apps(config))
        upload_saves(config)


def main() -> None:
    parser = argparse.ArgumentParser(prog="game-sync-epic")
    parser.add_argument("action", choices=["launch", "heroic"])
    parser.add_argument("app_name", nargs="?")
    args = parser.parse_args()
    if args.action == "launch" and not args.app_name:
        parser.error("launch needs an app name")
    config = load_config(os.environ.get("GAME_SYNC_CONFIG", _DEFAULT_CONFIG))
    if args.action == "heroic":
        sys.exit(open_heroic(config))
    sys.exit(launch(args.app_name, config))


if __name__ == "__main__":
    main()
