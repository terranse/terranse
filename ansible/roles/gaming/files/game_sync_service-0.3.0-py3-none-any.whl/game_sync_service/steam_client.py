"""Drive the Steam client already running in the gaming session.

Everything here was measured on the gaming VM (see the spike notes in
home-player/docs/superpowers/specs/2026-11-02-games-just-work-spikes.md), and
the odd parts have reasons:

- A launch's `AppId=` helper appears well before a Proton game does, so "started"
  comes from Steam's own log instead.
- A Proton game is not a child of Steam's reaper. What every game process does
  carry is `SteamAppId=<id>` in its environment.
- Never read `steam.pipe`: it blocks, and can swallow Steam's commands.
"""
from __future__ import annotations

import argparse
import os
import re
import shlex
import signal
import subprocess
import sys
import time
from pathlib import Path

from game_sync_service.config import load_config
from game_sync_service.steam_local import parse_acf

_DEFAULT_CONFIG = "/etc/game-sync/game-sync.conf"

# Up to 5 minutes from launch to running: a first launch compiles shaders.
START_TIMEOUT = 300.0
STEAM_READY_TIMEOUT = 180.0
# Proton hands off between processes while it starts and stops.
EXIT_SETTLE = 5.0
STOP_TIMEOUT = 25.0

_WRAPPERS = (
    "reaper", "pressure-vessel", "steam-runtime", "pv-adverb", "bwrap", "proton",
    "wineserver", "python",
)
_FULLY_INSTALLED = 4


def _environ(pid_dir: Path) -> list[bytes]:
    return (pid_dir / "environ").read_bytes().split(b"\0")


def _cmdline(pid_dir: Path) -> str:
    return (pid_dir / "cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "replace")


def processes_with_env(entry: str) -> list[tuple[int, str]]:
    """Every process, other than this one, with `entry` in its environment."""
    wanted = entry.encode()
    found = []
    for pid_dir in Path("/proc").glob("[0-9]*"):
        pid = int(pid_dir.name)
        if pid == os.getpid():
            continue
        try:
            if wanted in _environ(pid_dir):
                found.append((pid, _cmdline(pid_dir)))
        except OSError:
            continue  # gone, or not ours
    return found


def _cmdline_contains(*needles: str) -> list[Path]:
    matches = []
    for pid_dir in Path("/proc").glob("[0-9]*"):
        if int(pid_dir.name) == os.getpid():
            continue
        try:
            cmdline = _cmdline(pid_dir)
        except OSError:
            continue
        if all(n in cmdline for n in needles):
            matches.append(pid_dir)
    return matches


def game_running(appid: str) -> bool:
    return bool(processes_with_env(f"SteamAppId={appid}"))


def any_game_running() -> bool:
    return bool(_cmdline_contains("reaper", "SteamLaunch"))


def steam_ready() -> bool:
    # Steam's UI runs several of these once it is up; one or two are only starting.
    return len(_cmdline_contains("steamwebhelper")) > 2


def _wait_until(predicate, timeout: float, poll: float) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(poll)
    return predicate()


def _is_wrapper(cmdline: str) -> bool:
    # The program itself, not its arguments: Proton is handed the game's path.
    program = cmdline.split(" ", 1)[0]
    return any(w in program for w in _WRAPPERS)


def stop_targets(processes: list[tuple[int, str]]) -> list[int]:
    """The processes to signal to end a game.

    Only the game itself: Proton's wrappers unwind on their own once it exits,
    and signalling them first can leave the game behind.
    """
    own = [(pid, cmd) for pid, cmd in processes if not _is_wrapper(cmd)]
    executables = [
        pid for pid, cmd in own
        if ".exe" in cmd.lower() and "\\windows\\" not in cmd.lower()
    ]
    return executables or [pid for pid, _ in own]


def stop_game(env_entry: str, timeout: float = STOP_TIMEOUT, poll: float = 0.5) -> bool:
    for pid in stop_targets(processes_with_env(env_entry)):
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            continue
    return _wait_until(lambda: not processes_with_env(env_entry), timeout, poll)


class _LogWatch:
    """Lines added to a log since this was created."""

    def __init__(self, path: Path):
        self._path = path
        try:
            self._offset = path.stat().st_size
        except OSError:
            self._offset = 0

    def seen(self, pattern: re.Pattern) -> bool:
        try:
            with self._path.open("rb") as f:
                f.seek(self._offset)
                text = f.read().decode("utf-8", "replace")
        except OSError:
            return False
        return bool(pattern.search(text))


def supervise(
    env_entry: str,
    start,
    started,
    start_timeout: float = START_TIMEOUT,
    settle: float = EXIT_SETTLE,
    poll: float = 1.0,
) -> int:
    """Block for the life of a game, so Sunshine's stream lasts exactly as long.

    Ending the stream on SIGTERM (Moonlight's quit) ends the game too. A client
    merely disconnecting sends nothing, so reconnecting finds the game running.
    """

    def _on_term(_signum, _frame):
        stop_game(env_entry)
        sys.exit(0)

    signal.signal(signal.SIGTERM, _on_term)
    signal.signal(signal.SIGINT, _on_term)

    if not processes_with_env(env_entry):
        start()
        if not _wait_until(started, start_timeout, poll):
            print("game never started", file=sys.stderr)
            return 1

    quiet_since = None
    while True:
        if processes_with_env(env_entry):
            quiet_since = None
        elif quiet_since is None:
            quiet_since = time.monotonic()
        elif time.monotonic() - quiet_since >= settle:
            return 0
        time.sleep(poll)


def launch(appid: str, config) -> int:
    if not _wait_until(steam_ready, STEAM_READY_TIMEOUT, 1.0):
        print("Steam is not running", file=sys.stderr)
        return 1
    log = _LogWatch(config.steam_root / "logs" / "content_log.txt")
    running = re.compile(rf"AppID {re.escape(appid)} state changed : .*App Running")

    def start() -> None:
        subprocess.run(
            shlex.split(config.steam_cmd) + [f"steam://rungameid/{appid}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

    return supervise(f"SteamAppId={appid}", start, lambda: log.seen(running))


def _display_env() -> dict[str, str]:
    """Steam's own display, so a key press lands on Steam's dialog."""
    env = dict(os.environ)
    for pid_dir in _cmdline_contains("ubuntu12_32/steam"):
        try:
            entries = _environ(pid_dir)
        except OSError:
            continue
        for entry in entries:
            for name in (b"DISPLAY=", b"XAUTHORITY="):
                if entry.startswith(name):
                    key, _, value = entry.decode("utf-8", "replace").partition("=")
                    env[key] = value
        if "DISPLAY" in env:
            break
    return env


def _manifest(config, appid: str) -> dict[str, str] | None:
    for library in config.steam_library_paths:
        path = Path(library) / "steamapps" / f"appmanifest_{appid}.acf"
        try:
            return parse_acf(path.read_text(errors="replace"))
        except OSError:
            continue
    return None


def _flags(manifest: dict[str, str]) -> int:
    value = manifest.get("StateFlags", "0")
    return int(value) if value.isdigit() else 0


def progress_line(manifest: dict[str, str]) -> str | None:
    done, total = manifest.get("BytesDownloaded", ""), manifest.get("BytesToDownload", "")
    if not (done.isdigit() and total.isdigit()) or int(total) == 0:
        return None
    return f"progress {100 * int(done) / int(total):.2f} {done} {total}"


def install(appid: str, config, dialog_delay: float = 5.0, poll: float = 2.0) -> int:
    """Have Steam install a game, printing progress for the install queue.

    A key press on `steam://install`'s dialog is the only unattended route that
    works with Steam running: its default choice is the library marked as the
    default, and a hand-written manifest is ignored until Steam restarts.
    """
    if not _wait_until(steam_ready, STEAM_READY_TIMEOUT, 1.0):
        print("Steam is not running on the gaming VM")
        return 1
    # The dialog would land on top of a game being played.
    while any_game_running():
        time.sleep(poll)

    subprocess.run(
        shlex.split(config.steam_cmd) + [f"steam://install/{appid}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    for _attempt in range(2):
        time.sleep(dialog_delay)
        subprocess.run(["xdotool", "key", "Return"], env=_display_env(), check=False)
        if _wait_until(lambda: _manifest(config, appid) is not None, 15.0, 1.0):
            break
    else:
        print("Steam did not start the install")
        return 1

    while True:
        manifest = _manifest(config, appid)
        if manifest is None:
            print("The install was cancelled in Steam")
            return 1
        if _flags(manifest) == _FULLY_INSTALLED:
            return 0
        line = progress_line(manifest)
        if line:
            print(line, flush=True)
        time.sleep(poll)


def main() -> None:
    parser = argparse.ArgumentParser(prog="game-sync-steam")
    parser.add_argument("action", choices=["launch", "install"])
    parser.add_argument("appid")
    args = parser.parse_args()
    config = load_config(os.environ.get("GAME_SYNC_CONFIG", _DEFAULT_CONFIG))
    run = launch if args.action == "launch" else install
    sys.exit(run(args.appid, config))


if __name__ == "__main__":
    main()
