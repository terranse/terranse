"""Per-store install drivers.

Each driver is a command to run, a parser for its progress output, and a way
to turn a non-zero exit into something a person reading a TV screen can act
on. Only stores with a real headless installer get one; a game with no driver
is simply not offered as installable, which is better than an Install button
that always fails.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from game_sync_service.models import Game
from game_sync_service.legendary import legendary_base
from game_sync_service.progress import parse_legendary, parse_steam_client

_MAX_TAIL = 300

EPIC_AUTH_REASON = "Epic login expired — run `legendary auth` on the gaming VM"


@dataclass
class Driver:
    args: list[str]
    parse: Callable[[str], dict | None]
    classify_failure: Callable[[int, str], str]


def build_steam_args(appid: str) -> list[str]:
    # Beside this interpreter: only the main entry point is on PATH.
    return [str(Path(sys.executable).parent / "game-sync-steam"), "install", appid]


def build_legendary_args(config, app_name: str) -> list[str]:
    # DLC is an explicit choice: `-y` alone answers yes to all of it.
    args = legendary_base(config) + ["-y", "install", app_name, "--skip-dlcs", "--skip-sdl"]
    if getattr(config, "epic_install_dir", ""):
        args += ["--base-path", str(config.epic_install_dir)]
    return args


def _tail(text: str) -> str:
    return text.strip()[-_MAX_TAIL:]


def _steam_failure(code: int, tail: str) -> str:
    return _tail(tail) or f"Steam install helper exited {code}"


def _legendary_failure(code: int, tail: str) -> str:
    lowered = tail.lower()
    if "login" in lowered and ("fail" in lowered or "auth" in lowered):
        return EPIC_AUTH_REASON
    return f"legendary exited {code}: {_tail(tail)}"


def driver_for(game: Game, config) -> Driver | None:
    if game.source == "steam":
        if not (game.service_appid and config.steam_library_paths):
            return None
        return Driver(build_steam_args(game.service_appid), parse_steam_client, _steam_failure)

    if game.source == "epic" and game.service_appid:
        return Driver(
            build_legendary_args(config, game.service_appid),
            parse_legendary,
            _legendary_failure,
        )

    return None
