"""Recompiled and fan ports of console games, listed by hand in ports.toml.

Nothing installs these or extracts their assets: that is done off-stream, once.
So a port only counts as installed when both its program and its assets are there.
"""
from __future__ import annotations

import logging
import re
import shlex
import shutil
import tomllib
from dataclasses import dataclass
from pathlib import Path

from game_sync_service.models import Game

logger = logging.getLogger(__name__)

ID_PREFIX = "port-"
# It ends up in the command line Sunshine runs.
_SAFE_ID = re.compile(r"^[a-z0-9][a-z0-9_-]*$")


@dataclass
class Port:
    id: str
    name: str
    command: list[str]
    assets: list[Path]
    console: str
    window_class: str

    @property
    def game_id(self) -> str:
        return f"{ID_PREFIX}{self.id}"

    @property
    def installed(self) -> bool:
        return shutil.which(self.command[0]) is not None and all(a.exists() for a in self.assets)


def _text(entry: dict, key: str) -> str:
    value = entry.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"needs a `{key}`")
    return value


def _parse(entry) -> Port:
    if not isinstance(entry, dict):
        raise ValueError("is not a table")
    port_id = _text(entry, "id")
    if not _SAFE_ID.match(port_id):
        raise ValueError(f"has an unusable id {port_id!r}")
    command = shlex.split(_text(entry, "exec"))
    if not command:
        raise ValueError("needs an `exec`")
    command[0] = str(Path(command[0]).expanduser())
    assets = entry.get("assets")
    if not (isinstance(assets, list) and assets and all(isinstance(a, str) for a in assets)):
        raise ValueError("needs a list of `assets`")
    window_class = entry.get("window_class", re.escape(Path(command[0]).stem))
    if not isinstance(window_class, str):
        raise ValueError("has an unusable `window_class`")
    return Port(
        id=port_id,
        name=_text(entry, "name"),
        command=command,
        assets=[Path(a).expanduser() for a in assets],
        console=_text(entry, "console"),
        window_class=window_class,
    )


def load_ports(path: Path) -> list[Port]:
    """Every usable entry; one that isn't is logged, and costs only itself."""
    try:
        with open(path, "rb") as f:
            entries = tomllib.load(f).get("port", [])
    except FileNotFoundError:
        return []
    except (OSError, tomllib.TOMLDecodeError):
        logger.warning("Unreadable ports file: %s", path)
        return []
    if not isinstance(entries, list):
        logger.warning("`port` is not a list of tables in %s", path)
        return []
    ports: dict[str, Port] = {}
    for index, entry in enumerate(entries):
        try:
            port = _parse(entry)
        except ValueError as exc:
            logger.warning("Skipping entry %d of %s: it %s", index + 1, path, exc)
            continue
        if port.id in ports:
            logger.warning("Skipping entry %d of %s: %s is already listed", index + 1, path, port.id)
            continue
        ports[port.id] = port
    return list(ports.values())


def ports_path(config) -> Path:
    return config.data_dir / "ports.toml"


def scan_ports(config) -> list[Game]:
    return [
        Game(
            id=port.game_id,
            name=port.name,
            source="port",
            platform=port.console,
            state="installed" if port.installed else "not_installed",
            service_appid=port.id,
            slug=port.id,
        )
        for port in load_ports(ports_path(config))
    ]
