from __future__ import annotations

import configparser
import socket
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Config:
    port: int
    hostname: str
    lutris_db_path: Path
    lutris_cmd: str
    lutris_coverart_dir: Path | None
    sunshine_apps_path: Path
    sunshine_reload_cmd: str
    cover_cache_dir: Path
    game_profiles_path: Path
    data_dir: Path
    steam_enabled: bool
    epic_enabled: bool
    gog_enabled: bool
    retroarch_enabled: bool
    retroarch_rom_path: Path | None
    retroarch_cmd: str
    retroarch_core_dir: Path
    igdb_client_id: str
    igdb_client_secret: str
    steamgriddb_api_key: str
    # Steam libraries read directly, so installed games are visible without
    # Lutris ever having run. Defaulted so existing callers that build a
    # Config positionally keep working.
    steam_library_paths: list[Path] = field(default_factory=list)
    # Owned-but-not-installed catalogue. Readable with the gaming VM asleep.
    steam_web_api_key: str = ""
    steam_id: str = ""
    install_enabled: bool = False
    steam_restart_cmd: str = "systemctl --user restart gamescope-session"
    steam_cmd: str = "flatpak run com.valvesoftware.Steam"
    steam_root: Path = Path.home() / ".var/app/com.valvesoftware.Steam/.local/share/Steam"
    legendary_cmd: str = "legendary"
    legendary_config_dir: str = ""
    epic_install_dir: str = ""
    epic_proton_dir: str = ""
    # Local disk: Proton prefixes can hang on the virtiofs pool (no POSIX locks).
    epic_prefix_dir: str = "/var/lib/game-sync/prefixes"
    # Store-less games copied in as folders, each with a game.toml.
    local_games_dir: Path = Path("/var/lib/game-sync/games")
    # Local disk, whatever the games are on, for the same reason as above.
    local_prefix_dir: Path = Path("/var/lib/game-sync/local-prefixes")
    local_proton_dir: str = ""
    gpu_manager_api_url: str = ""
    gpu_manager_vm_name: str = "gaming"
    # How many ROMs per system get a card of their own, on top of any pinned.
    retroarch_showcase_cap: int = 3
    # Unset means a `saves` folder beside the ROM folder, which is read-only.
    retroarch_save_dir: Path | None = None
    esde_cmd: str = "es-de"

    @property
    def steam_owned_enabled(self) -> bool:
        return bool(self.steam_web_api_key and self.steam_id)

    @property
    def igdb_enabled(self) -> bool:
        return bool(self.igdb_client_id and self.igdb_client_secret)

    @property
    def sgdb_enabled(self) -> bool:
        return bool(self.steamgriddb_api_key)


def _opt_path(value: str) -> Path | None:
    return Path(value) if value else None


def load_config(path: str | Path) -> Config:
    parser = configparser.ConfigParser()
    if not parser.read(path):
        raise FileNotFoundError(path)
    data_dir = Path(parser.get("storage", "data_dir", fallback="/var/lib/game-sync"))
    epic_proton_dir = parser.get("install", "epic_proton_dir", fallback="")
    return Config(
        port=parser.getint("general", "port", fallback=9766),
        hostname=parser.get("general", "hostname", fallback=socket.gethostname()),
        lutris_db_path=Path(parser.get("lutris", "db_path")),
        lutris_cmd=parser.get("lutris", "lutris_cmd", fallback="lutris"),
        lutris_coverart_dir=_opt_path(parser.get("lutris", "coverart_dir", fallback="")),
        sunshine_apps_path=Path(parser.get("sunshine", "apps_path")),
        sunshine_reload_cmd=parser.get("sunshine", "reload_cmd", fallback=""),
        cover_cache_dir=Path(parser.get("storage", "cover_cache_dir")),
        game_profiles_path=Path(parser.get("storage", "game_profiles_path")),
        data_dir=data_dir,
        steam_enabled=parser.getboolean("stores", "steam_enabled", fallback=True),
        epic_enabled=parser.getboolean("stores", "epic_enabled", fallback=True),
        gog_enabled=parser.getboolean("stores", "gog_enabled", fallback=True),
        retroarch_enabled=parser.getboolean("stores", "retroarch_enabled", fallback=False),
        retroarch_rom_path=_opt_path(parser.get("stores", "retroarch_rom_path", fallback="")),
        retroarch_cmd=parser.get(
            "stores", "retroarch_cmd", fallback="flatpak run org.libretro.RetroArch"
        ),
        retroarch_core_dir=Path(
            parser.get(
                "stores", "retroarch_core_dir", fallback="/usr/lib/x86_64-linux-gnu/libretro"
            )
        ),
        retroarch_showcase_cap=max(
            0, parser.getint("stores", "retroarch_showcase_cap", fallback=3)
        ),
        retroarch_save_dir=_opt_path(parser.get("stores", "retroarch_save_dir", fallback="")),
        esde_cmd=parser.get("stores", "esde_cmd", fallback="es-de"),
        steam_cmd=parser.get(
            "stores", "steam_cmd", fallback="flatpak run com.valvesoftware.Steam"
        ),
        steam_root=Path(
            parser.get(
                "stores",
                "steam_root",
                fallback=str(
                    Path.home() / ".var/app/com.valvesoftware.Steam/.local/share/Steam"
                ),
            )
        ),
        igdb_client_id=parser.get("metadata", "igdb_client_id", fallback=""),
        igdb_client_secret=parser.get("metadata", "igdb_client_secret", fallback=""),
        steamgriddb_api_key=parser.get("metadata", "steamgriddb_api_key", fallback=""),
        steam_library_paths=[
            Path(p)
            for p in parser.get("stores", "steam_library_paths", fallback="").split(":")
            if p
        ],
        steam_web_api_key=parser.get("metadata", "steam_web_api_key", fallback=""),
        steam_id=parser.get("metadata", "steam_id", fallback=""),
        install_enabled=parser.getboolean("install", "enabled", fallback=False),
        steam_restart_cmd=parser.get(
            "install", "steam_restart_cmd", fallback="systemctl --user restart gamescope-session"
        ),
        legendary_cmd=parser.get("install", "legendary_cmd", fallback="legendary"),
        legendary_config_dir=parser.get("install", "legendary_config_dir", fallback=""),
        epic_install_dir=parser.get("install", "epic_install_dir", fallback=""),
        epic_proton_dir=epic_proton_dir,
        epic_prefix_dir=parser.get(
            "install", "epic_prefix_dir", fallback="/var/lib/game-sync/prefixes"
        ),
        local_games_dir=Path(
            parser.get("stores", "local_games_dir", fallback="/var/lib/game-sync/games")
        ),
        local_prefix_dir=Path(
            parser.get("stores", "local_prefix_dir", fallback=str(data_dir / "local-prefixes"))
        ),
        local_proton_dir=parser.get("stores", "local_proton_dir", fallback=epic_proton_dir),
        gpu_manager_api_url=parser.get("gpu_manager", "api_url", fallback=""),
        gpu_manager_vm_name=parser.get("gpu_manager", "vm_name", fallback="gaming"),
    )
