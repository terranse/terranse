"""Launch store-less games with umu-launcher and GE-Proton."""
from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
from pathlib import Path

from game_sync_service.config import load_config
from game_sync_service.epic_client import GamescopeFocus, gamescope_id
from game_sync_service.local_games import LocalGame, load_game
from game_sync_service.steam_client import (
    _DEFAULT_CONFIG,
    _display_env,
    _environ,
    processes_with_env,
    supervise,
)

# Set on every process of a local game. Not PROTONPATH, as Epic's check uses,
# because a game can pin its own Proton.
_MARKER = "GAME_SYNC_LOCAL"


def prefix_for(config, slug: str) -> Path:
    return Path(config.local_prefix_dir) / slug


def proton_for(config, game: LocalGame) -> str:
    if not game.proton:
        return config.local_proton_dir
    # Versions sit side by side; a full path replaces the parent altogether.
    return str(Path(config.local_proton_dir).parent / game.proton)


def _gameid(game: LocalGame) -> str:
    return game.umu_id or f"umu-{gamescope_id(f'local-{game.slug}')}"


def launch_env(config, game: LocalGame, base: dict[str, str]) -> dict[str, str]:
    env = dict(base)
    # Inside gamescope, not beside it: with sway's socket visible the game would
    # open as a sway window instead.
    env.pop("WAYLAND_DISPLAY", None)
    env.update(game.env)
    env.update(
        {
            "WINEPREFIX": str(prefix_for(config, game.slug)),
            "PROTONPATH": proton_for(config, game),
            "GAMEID": _gameid(game),
            # umu would share only the exe's parent with the container.
            "STEAM_COMPAT_INSTALL_PATH": str(game.folder),
            _MARKER: game.slug,
        }
    )
    return env


def focus_for(game: LocalGame, env: dict[str, str]) -> GamescopeFocus:
    # The app id as umu works it out from GAMEID, which Proton names windows after.
    # Gamescope only takes numbers, so a named id still needs one of its own.
    match = re.fullmatch(r"umu-(\w+)", _gameid(game))
    app_id = match[1] if match else "0"
    if app_id.isdigit() and int(app_id):
        return GamescopeFocus(int(app_id), env)
    return GamescopeFocus(f"local-{game.slug}", env, rf"^steam_app_{re.escape(app_id)}$")


def local_game_running() -> bool:
    prefix = f"{_MARKER}=".encode()
    for pid_dir in Path("/proc").glob("[0-9]*"):
        if int(pid_dir.name) == os.getpid():
            continue
        try:
            if any(entry.startswith(prefix) for entry in _environ(pid_dir)):
                return True
        except OSError:
            continue  # gone, or not ours
    return False


def _run(config, game: LocalGame, target: Path, args: list[str]) -> int:
    if not target.is_file():
        print(f"{game.slug}: {target} does not exist", file=sys.stderr)
        return 1
    proton = proton_for(config, game)
    if not (proton and Path(proton).is_dir()):
        print(f"{game.slug}: no Proton at {proton!r}", file=sys.stderr)
        return 1
    prefix_for(config, game.slug).mkdir(parents=True, exist_ok=True)
    env_entry = f"{_MARKER}={game.slug}"
    display = _display_env()
    child = None

    def start() -> None:
        nonlocal child
        # Blocks for as long as the game runs, so it can't be waited on here.
        child = subprocess.Popen(
            ["umu-run", str(target), *args],
            env=launch_env(config, game, display),
            # Old games read their data relative to where they start.
            cwd=target.parent,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    def started() -> bool:
        # A launch that has already died has nothing to wait for: without this the
        # TV shows a blank stream until the start timeout.
        return bool(processes_with_env(env_entry)) or child.poll() is not None

    return supervise(env_entry, start, started, tick=focus_for(game, display))


def _load(config, slug: str) -> LocalGame | None:
    try:
        return load_game(config, slug)
    except (OSError, ValueError) as exc:
        print(f"{slug}: {exc}", file=sys.stderr)
        return None


def launch(slug: str, config) -> int:
    game = _load(config, slug)
    return _run(config, game, game.executable, game.args) if game else 1


def setup(slug: str, config) -> int:
    """Run a game's installer, in the prefix the game will use afterwards."""
    game = _load(config, slug)
    if game is None:
        return 1
    if game.installer_path is None:
        print(f"{slug}: no installer in its manifest", file=sys.stderr)
        return 1
    return _run(config, game, game.installer_path, [])


def main() -> None:
    parser = argparse.ArgumentParser(prog="game-sync-local")
    parser.add_argument("action", choices=["launch", "setup"])
    parser.add_argument("slug")
    args = parser.parse_args()
    config = load_config(os.environ.get("GAME_SYNC_CONFIG", _DEFAULT_CONFIG))
    sys.exit(setup(args.slug, config) if args.action == "setup" else launch(args.slug, config))


if __name__ == "__main__":
    main()
