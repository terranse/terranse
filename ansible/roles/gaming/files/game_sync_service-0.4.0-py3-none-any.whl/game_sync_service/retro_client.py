"""Launch retro games so that a stream lasts exactly as long as they do.

Their launch is the same problem as an Epic game's: nothing but this process ties
the stream to the game, and in its Steam mode gamescope won't show a window nobody
has tagged. The ROM share is read-only and may not honour file locks, so nothing is
written there and everything this keeps for itself is on local disk.
"""
from __future__ import annotations

import argparse
import os
import shlex
import sqlite3
import subprocess
import sys
from pathlib import Path

from game_sync_service.config import load_config
from game_sync_service.epic_client import GamescopeFocus
from game_sync_service.models import Game
from game_sync_service.ports import ID_PREFIX, load_ports, ports_path
from game_sync_service.retroarch import scan_retroarch_games
from game_sync_service.steam_client import (
    _DEFAULT_CONFIG,
    _display_env,
    processes_with_env,
    supervise,
)
from game_sync_service.store import MetadataStore
from game_sync_service.sunshine import _atomic_write

# On every process of a retro game, from the launcher's child to the emulator.
_MARK = "GAME_SYNC_RETRO"
_MARK_ID = "GAME_SYNC_RETRO_ID"
# In the save folder because RetroArch has to reach that anyway, which from inside
# its Flatpak takes a filesystem permission; this way it needs no second one.
LAUNCH_CONFIG = "game-sync-retroarch.cfg"
# RetroArch too: it is what ES-DE starts, and gamescope would leave ES-DE on top.
_ES_DE_WINDOWS = "es-de|retroarch"


def retro_game_running() -> bool:
    return bool(processes_with_env(f"{_MARK}=1"))


def save_dir(config) -> Path:
    return config.retroarch_save_dir or config.retroarch_rom_path.parent / "saves"


def write_launch_config(saves: Path) -> Path:
    """RetroArch's settings for a launch, overriding whatever its own config says."""
    states = saves / "states"
    states.mkdir(parents=True, exist_ok=True)
    path = saves / LAUNCH_CONFIG
    settings = {
        "savefile_directory": saves,
        "savestate_directory": states,
        "savefiles_in_content_dir": "false",
        "savestates_in_content_dir": "false",
        "systemfiles_in_content_dir": "false",
        "screenshots_in_content_dir": "false",
        "video_fullscreen": "true",
        # Or quitting would write this launch's settings into RetroArch's own config.
        "config_save_on_exit": "false",
    }
    _atomic_write(path, "".join(f'{key} = "{value}"\n' for key, value in settings.items()))
    return path


def retroarch_command(game: Game, config, launch_config: Path) -> list[str]:
    core = config.retroarch_core_dir / f"{game.emulator}_libretro.so"
    return [
        *shlex.split(config.retroarch_cmd),
        "-L", str(core),
        f"--appendconfig={launch_config}",
        game.rom_path,
    ]


def _record_played(config, game_id: str) -> None:
    try:
        store = MetadataStore(config.data_dir / "metadata.db")
        try:
            store.record_played(game_id)
        finally:
            store.close()
    except (OSError, sqlite3.Error) as exc:
        # Only the homescreen's choice of games hangs on this, not the game.
        print(f"could not record {game_id} as played: {exc}", file=sys.stderr)


def _run(run_id: str, command: list[str], windows: str, on_start=None, cwd=None) -> int:
    env_entry = f"{_MARK_ID}={run_id}"
    display = _display_env()
    env = dict(display)
    # Inside gamescope, not beside it: with sway's socket visible the game would
    # open as a sway window instead.
    env.pop("WAYLAND_DISPLAY", None)
    env.update({_MARK: "1", _MARK_ID: run_id})
    started: dict[str, subprocess.Popen] = {}

    def start() -> None:
        started["proc"] = subprocess.Popen(
            command, env=env, cwd=cwd, stdout=subprocess.DEVNULL, stderr=None
        )
        if on_start:
            on_start()

    def has_started() -> bool:
        # Already gone counts: there's no point in holding the stream for five
        # minutes waiting on an emulator that has given up.
        proc = started.get("proc")
        return bool(processes_with_env(env_entry)) or (proc is not None and proc.poll() is not None)

    try:
        return supervise(
            env_entry, start, has_started, tick=GamescopeFocus(run_id, display, windows)
        )
    except OSError as exc:
        print(f"could not start {command[0]}: {exc}", file=sys.stderr)
        return 1


def launch_port(game_id: str, config) -> int:
    port = next((p for p in load_ports(ports_path(config)) if p.game_id == game_id), None)
    if port is None or not port.installed:
        print(f"no such port, or it is missing files: {game_id}", file=sys.stderr)
        return 1
    program = Path(port.command[0])
    return _run(
        game_id,
        port.command,
        port.window_class,
        on_start=lambda: _record_played(config, game_id),
        # Ports tend to look for their assets relative to themselves.
        cwd=program.parent if program.is_absolute() else None,
    )


def launch(game_id: str, config) -> int:
    if game_id.startswith(ID_PREFIX):
        return launch_port(game_id, config)
    game = next((g for g in scan_retroarch_games(config) if g.id == game_id), None)
    if game is None:
        print(f"no such game: {game_id}", file=sys.stderr)
        return 1
    try:
        launch_config = write_launch_config(save_dir(config))
    except OSError as exc:
        # It would run, and then quietly lose every save.
        print(f"no usable save folder: {exc}", file=sys.stderr)
        return 1
    return _run(
        game_id,
        retroarch_command(game, config, launch_config),
        "retroarch",
        on_start=lambda: _record_played(config, game_id),
    )


def open_es_de(config) -> int:
    """ES-DE for a Sunshine entry to run, as `game-sync-epic heroic` does Heroic."""
    return _run("es-de", shlex.split(config.esde_cmd), _ES_DE_WINDOWS)


def main() -> None:
    parser = argparse.ArgumentParser(prog="game-sync-retro")
    parser.add_argument("action", choices=["launch", "es-de"])
    parser.add_argument("game_id", nargs="?")
    args = parser.parse_args()
    if args.action == "launch" and not args.game_id:
        parser.error("launch needs a game id")
    config = load_config(os.environ.get("GAME_SYNC_CONFIG", _DEFAULT_CONFIG))
    if args.action == "es-de":
        sys.exit(open_es_de(config))
    sys.exit(launch(args.game_id, config))


if __name__ == "__main__":
    main()
