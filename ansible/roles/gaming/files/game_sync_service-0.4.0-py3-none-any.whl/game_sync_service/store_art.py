"""Artwork from the stores themselves, which needs no API key.

Steam's CDN serves art by app id, and Epic lists its art with each game. Without this a library with no IGDB or
SteamGridDB keys is a row of black cards, and the loading screen has nothing to
bring into focus. Downloaded into the same cache as other art, so it survives the
network being down.
"""
from __future__ import annotations

import logging
from pathlib import Path

import httpx

from game_sync_service.models import Enrichment, Game

logger = logging.getLogger(__name__)

_STEAM = "https://cdn.cloudflare.steamstatic.com/steam/apps/{appid}/{name}"


def steam_art_urls(appid: str) -> dict[str, list[str]]:
    """Candidates per kind, best first. Not every game has the library artwork,
    but every one sampled has a header."""
    url = lambda name: _STEAM.format(appid=appid, name=name)
    return {
        "cover": [url("library_600x900.jpg"), url("header.jpg")],
        "backdrop": [url("library_hero.jpg"), url("header.jpg")],
        "logo": [url("logo.png")],
    }


def _art_urls(game: Game) -> dict[str, list[str]]:
    if game.steam_lookup_id:
        return steam_art_urls(game.steam_lookup_id)
    return game.art_urls


async def _download(client: httpx.AsyncClient, urls: list[str], dest: Path) -> bool:
    for url in urls:
        try:
            resp = await client.get(url, timeout=20)
        except httpx.HTTPError as exc:
            logger.debug("art download failed: %s", exc)
            return False
        if resp.status_code == 200 and resp.content:
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_suffix(dest.suffix + ".part")
            tmp.write_bytes(resp.content)
            tmp.replace(dest)
            return True
    return False


class StoreArt:
    def __init__(self, config, store, client: httpx.AsyncClient):
        self._art_root = config.cover_cache_dir
        self._store = store
        self._client = client
        # What has been tried this run: some art doesn't exist, and asking again
        # every minute would change nothing.
        self._tried: set[str] = set()

    def _paths(self, game_id: str) -> dict[str, Path]:
        return {
            "cover": self._art_root / f"{game_id}.jpg",
            "backdrop": self._art_root / "backdrops" / f"{game_id}.jpg",
            "logo": self._art_root / "logos" / f"{game_id}.png",
        }

    async def fill(self, games: list[Game]) -> None:
        """Fetch whatever art is missing, installed games first."""
        wanted = [g for g in games if _art_urls(g) and g.id not in self._tried]
        wanted.sort(key=lambda g: g.state != "installed")
        for game in wanted:
            self._tried.add(game.id)
            paths = self._paths(game.id)
            urls = _art_urls(game)
            changed = False
            for kind, dest in paths.items():
                if not dest.exists() and kind in urls:
                    changed = await _download(self._client, urls[kind], dest) or changed
            if changed:
                self._record(game.id, paths)

    def _record(self, game_id: str, paths: dict[str, Path]) -> None:
        enrichment = self._store.get(game_id) or Enrichment(game_id=game_id)
        enrichment.has_cover = paths["cover"].exists()
        enrichment.has_backdrop = paths["backdrop"].exists()
        enrichment.has_logo = paths["logo"].exists()
        # Still pending if nothing has looked at it, so keys added later are used.
        self._store.upsert(enrichment, status=self._store.status(game_id) or "pending")
