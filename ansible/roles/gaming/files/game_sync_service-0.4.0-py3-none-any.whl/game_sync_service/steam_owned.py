"""The owned Steam catalogue, from the Steam Web API.

Deliberately a network call rather than a read of anything on the gaming VM:
this is what lets the browse screen list everything you own while the VM is
powered off. Install state is decided elsewhere — see `steam_local` — so
every game here is reported `not_installed` and merged over by the
filesystem scanner when it is in fact installed.
"""
from __future__ import annotations

import logging

import httpx

from game_sync_service.models import Game

logger = logging.getLogger(__name__)

_URL = "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/"


async def fetch_steam_owned(config, client: httpx.AsyncClient) -> list[Game]:
    if not config.steam_owned_enabled:
        return []

    # A header rather than the documented `key` parameter: httpx puts the URL
    # in its request logs and status errors, which would land the key in the journal.
    headers = {"x-webapi-key": config.steam_web_api_key}
    params = {
        "steamid": config.steam_id,
        "include_appinfo": 1,
        "include_played_free_games": 1,
        "format": "json",
    }
    try:
        resp = await client.get(_URL, params=params, headers=headers, timeout=30)
        resp.raise_for_status()
        entries = resp.json()["response"]["games"]
    except (httpx.HTTPError, KeyError, TypeError, ValueError) as exc:
        # Fail soft: a Steam outage or a bad key must degrade the catalogue,
        # never empty the library or abort the scan.
        logger.warning("Steam owned-games fetch failed: %s", exc)
        return []

    games: list[Game] = []
    for entry in entries:
        appid, name = entry.get("appid"), entry.get("name")
        if not appid or not name:
            continue
        games.append(
            Game(
                id=f"steam-{appid}",
                name=name,
                source="steam",
                platform="windows",
                state="not_installed",
                service_appid=str(appid),
            )
        )
    return games
