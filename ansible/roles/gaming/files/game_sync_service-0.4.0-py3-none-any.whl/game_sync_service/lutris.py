from __future__ import annotations

import shutil
import sqlite3
import tempfile
from pathlib import Path

from game_sync_service.config import Config
from game_sync_service.models import Game

SERVICE_TO_SOURCE = {"steam": "steam", "egs": "epic", "gog": "gog"}

_WANTED = [
    "id", "name", "slug", "runner", "platform",
    "installed", "installed_at", "year", "service", "service_id",
]


def _source_enabled(source: str, config: Config) -> bool:
    return {
        "steam": config.steam_enabled,
        "epic": config.epic_enabled,
        "gog": config.gog_enabled,
    }.get(source, True)


def _read(config: Config, fn) -> list[sqlite3.Row]:
    """Run `fn(conn)` against a private copy of the Lutris database.

    Lutris may hold the live file open mid-write, so it is never opened
    directly. A schema that does not match what upstream documents is treated
    as an absent table rather than an error: one unfamiliar Lutris version
    must not take the whole scan down with it.
    """
    if not config.lutris_db_path.exists():
        return []
    with tempfile.TemporaryDirectory(prefix="game-sync-pga") as tmp:
        copy = Path(tmp) / "pga.db"
        shutil.copy(config.lutris_db_path, copy)
        conn = sqlite3.connect(f"file:{copy}?mode=ro", uri=True)
        try:
            conn.row_factory = sqlite3.Row
            return fn(conn)
        except sqlite3.Error:
            return []
        finally:
            conn.close()


def read_lutris_games(config: Config) -> list[Game]:
    def query(conn: sqlite3.Connection) -> list[sqlite3.Row]:
        available = {r[1] for r in conn.execute("PRAGMA table_info(games)")}
        select = ", ".join(c for c in _WANTED if c in available)
        return conn.execute(f"SELECT {select} FROM games").fetchall()

    rows = _read(config, query)

    games: list[Game] = []
    for row in rows:
        r = dict(row)
        name, slug = r.get("name"), r.get("slug")
        if not name or not slug:
            continue
        source = SERVICE_TO_SOURCE.get(r.get("service") or "", "lutris")
        if not _source_enabled(source, config):
            continue
        service_id = r.get("service_id")
        game_id = f"{source}-{service_id}" if source != "lutris" and service_id else f"lutris-{slug}"
        platform = r.get("platform")
        games.append(
            Game(
                id=game_id,
                name=name,
                source=source,
                platform=platform.lower() if platform else None,
                state="installed" if r.get("installed") else "not_installed",
                installed_at=r.get("installed_at"),
                slug=slug,
                service_appid=service_id if source == "steam" else None,
                release_year_hint=r.get("year"),
                lutris_id=r.get("id"),
            )
        )
    return games


def read_lutris_service_games(config: Config) -> list[Game]:
    """The synced store catalogue — everything owned, installed or not.

    Lutris keeps this in `service_games`, separate from `games` (which holds
    only what has been added locally). That distinction is the whole reason
    this reader exists: the install catalogue is invisible from `games`.

    IDs are built with the same `{source}-{store_id}` scheme the direct
    scanners use, so a row here and a Steam Web API row for the same title
    collide on identity and merge without any title matching.
    """
    def query(conn: sqlite3.Connection) -> list[sqlite3.Row]:
        return conn.execute(
            "SELECT service, appid, name, slug FROM service_games"
        ).fetchall()

    games: list[Game] = []
    for row in _read(config, query):
        r = dict(row)
        name, appid = r.get("name"), r.get("appid")
        if not name or not appid:
            continue
        source = SERVICE_TO_SOURCE.get(r.get("service") or "", "lutris")
        # Services with no store mapping (humblebundle, itchio, …) have no
        # install driver, so a catalogue entry for them is unusable.
        if source == "lutris" or not _source_enabled(source, config):
            continue
        games.append(
            Game(
                id=f"{source}-{appid}",
                name=name,
                source=source,
                platform=None,
                state="not_installed",
                slug=r.get("slug"),
                service_appid=appid if source == "steam" else None,
            )
        )
    return games
