from __future__ import annotations

import json
import logging
from pathlib import Path

from game_sync_service.models import Game

logger = logging.getLogger(__name__)

# The vGPU slice each console gets, for ROMs and ports alike. All whole-card for
# now: the card holds one size of slice at a time and the AI VM claims Q-24C, so a
# smaller claim frees nothing and would restart the VM to reshape the card. Lower
# these once something can share it. Only Q-8C, Q-12C and Q-24C can be claimed.
DEFAULT_CONSOLE_PROFILE = "Q-24C"
CONSOLE_PROFILES: dict[str, str] = {
    "nes": "Q-24C",
    "snes": "Q-24C",
    "n64": "Q-24C",
    "genesis": "Q-24C",
    "megadrive": "Q-24C",
    "mastersystem": "Q-24C",
    "gamegear": "Q-24C",
    "gb": "Q-24C",
    "gbc": "Q-24C",
    "gba": "Q-24C",
    "nds": "Q-24C",
    "psx": "Q-24C",
    "ps2": "Q-24C",
    "psp": "Q-24C",
    "gamecube": "Q-24C",
    "gc": "Q-24C",
    "wii": "Q-24C",
    # No core for these today; ports and later emulators.
    "wiiu": "Q-24C",
    "ps3": "Q-24C",
    "switch": "Q-24C",
}


def load_profiles(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return None
    except (OSError, json.JSONDecodeError):
        logger.warning("Unreadable game profiles file: %s", path)
        return None


def recommended_profile(game: Game, profiles: dict | None) -> str | None:
    if game.source in ("retroarch", "port"):
        return CONSOLE_PROFILES.get(game.platform, DEFAULT_CONSOLE_PROFILE)
    if profiles is None:
        return None
    table = profiles.get("profiles", {})
    if game.source == "steam" and game.service_appid:
        entry = table.get(f"steam:{game.service_appid}")
    else:
        entry = None
    if entry and entry.get("recommended_profile"):
        return entry["recommended_profile"]
    return profiles.get("defaults", {}).get("unknown_game")
