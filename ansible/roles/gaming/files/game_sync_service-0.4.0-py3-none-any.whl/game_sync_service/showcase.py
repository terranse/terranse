"""Which ROMs get a homescreen card; ES-DE is the way to all the others."""
from __future__ import annotations

import logging
import tomllib
from collections import defaultdict
from pathlib import Path

from game_sync_service.models import Enrichment, Game

logger = logging.getLogger(__name__)

# Below this a rating says little: one enthusiast can make an obscure game a 100.
VOTE_FLOOR = 20


def load_pins(path: Path) -> set[str]:
    try:
        with open(path, "rb") as f:
            pins = tomllib.load(f).get("pins", [])
    except FileNotFoundError:
        return set()
    except (OSError, tomllib.TOMLDecodeError):
        logger.warning("Unreadable showcase file: %s", path)
        return set()
    if not isinstance(pins, list):
        logger.warning("`pins` is not a list in %s", path)
        return set()
    wanted = {pin for pin in pins if isinstance(pin, str)}
    if len(wanted) != len(pins):
        logger.warning("Ignoring pins that are not game ids in %s", path)
    return wanted


def _pick_for_system(
    roms: list[Game],
    cap: int,
    pins: set[str],
    last_played: dict[str, float],
    enrichments: dict[str, Enrichment],
) -> set[str]:
    # Pins were asked for by name, so they take no notice of the cap.
    chosen = {rom.id for rom in roms if rom.id in pins}

    def take(candidates: list[Game]) -> None:
        for rom in candidates:
            if len(chosen) >= cap:
                return
            chosen.add(rom.id)

    roms = sorted(roms, key=lambda rom: (rom.name, rom.id))
    played = [rom for rom in roms if rom.id in last_played and rom.id not in chosen]
    take(sorted(played, key=lambda rom: -last_played[rom.id]))

    def rating(rom: Game) -> float | None:
        enr = enrichments.get(rom.id)
        if enr is None or enr.total_rating is None or (enr.total_rating_count or 0) < VOTE_FLOOR:
            return None
        return enr.total_rating

    rated = [rom for rom in roms if rating(rom) is not None]
    if rated:
        take(sorted((r for r in rated if r.id not in chosen), key=lambda rom: -rating(rom)))
    else:
        # No keys, or nothing matched yet. The order only has to hold still, so
        # that cards and Sunshine's entries don't change from one scan to the next.
        take([rom for rom in roms if rom.id not in chosen])
    return chosen


def select_showcase(
    games: list[Game],
    *,
    cap: int,
    pins: set[str] | None = None,
    last_played: dict[str, float] | None = None,
    enrichments: dict[str, Enrichment] | None = None,
) -> set[str]:
    """The ids of the ROMs to show: at most `cap` per system, plus any pinned."""
    systems: dict[str | None, list[Game]] = defaultdict(list)
    for game in games:
        if game.source == "retroarch":
            systems[game.platform].append(game)
    chosen: set[str] = set()
    for roms in systems.values():
        chosen |= _pick_for_system(roms, cap, pins or set(), last_played or {}, enrichments or {})
    return chosen
