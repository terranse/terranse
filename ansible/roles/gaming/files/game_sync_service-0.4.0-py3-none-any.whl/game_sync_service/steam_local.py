"""Installed Steam games, read straight from the library on disk.

Steam records every installed app as `steamapps/appmanifest_<appid>.acf` in
Valve's KeyValues format. Reading those is what lets game-sync see the real
library without Lutris — which matters because Lutris has never successfully
synced on the gaming VM, and because the library lives on a shared pool that
is readable with the VM powered off.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path

from game_sync_service.models import Game

logger = logging.getLogger(__name__)

_PAIR = re.compile(r'^\s*"([^"]+)"\s+"([^"]*)"\s*$')

# Steam installs its own tooling as ordinary appmanifests, with nothing in the
# file to tell them from games. Only the exact Proton variants match, because
# "Proton" alone is a word a game could start with.
_TOOL_NAME = re.compile(
    r"^(Steam Linux Runtime\b"
    r"|Steamworks Common Redistributables$"
    r"|Proton (\d|Experimental$|Next$|Hotfix$|EasyAntiCheat Runtime$|BattlEye Runtime$))"
)


def parse_acf(text: str) -> dict[str, str]:
    """Top-level scalars of an appmanifest.

    KeyValues nests with braces, and nested blocks reuse key names — a
    manifest's `UserConfig` block has its own `name`. Tracking depth and
    keeping only pairs directly inside the root block stops those from
    shadowing the real fields.
    """
    out: dict[str, str] = {}
    depth = 0
    for line in text.splitlines():
        stripped = line.strip()
        if stripped == "{":
            depth += 1
            continue
        if stripped == "}":
            depth -= 1
            continue
        if depth != 1:
            continue
        match = _PAIR.match(line)
        if match:
            out[match.group(1)] = match.group(2)
    return out


def _first_install_in_progress(fields: dict[str, str]) -> bool:
    """Still downloading for the first time, so nothing there to play yet.

    An update clears the fully-installed flag too (1026), but that game still has
    its files and must keep its Play button, so size on disk tells them apart.
    """
    flags = fields.get("StateFlags", "")
    if not flags.isdigit() or int(flags) & 4:
        return False
    return fields.get("SizeOnDisk", "0") == "0"


def scan_steam_local(config) -> list[Game]:
    games: list[Game] = []
    for library in config.steam_library_paths:
        steamapps = Path(library) / "steamapps"
        if not steamapps.is_dir():
            continue
        for manifest in sorted(steamapps.glob("appmanifest_*.acf")):
            try:
                fields = parse_acf(manifest.read_text(errors="replace"))
            except OSError:
                logger.warning("unreadable Steam manifest %s", manifest)
                continue
            appid, name = fields.get("appid"), fields.get("name")
            if not appid or not name or _TOOL_NAME.match(name):
                continue
            if _first_install_in_progress(fields):
                continue
            last_updated = fields.get("LastUpdated", "")
            games.append(
                Game(
                    id=f"steam-{appid}",
                    name=name,
                    source="steam",
                    platform="windows",
                    state="installed",
                    service_appid=appid,
                    installed_at=int(last_updated) if last_updated.isdigit() else None,
                )
            )
    return games
