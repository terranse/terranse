"""The install queue.

Deliberately serialized: one install at a time. Downloads saturate the link
and every driver writes the same pool, so running two in parallel buys no
wall-clock and makes progress reporting ambiguous — two jobs at 50% tells you
nothing useful about when either finishes.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import UTC, datetime

from game_sync_service.drivers import driver_for
from game_sync_service.models import Game, InstallJob, job_cancellable

logger = logging.getLogger(__name__)

# Enough of the installer's output to diagnose a failure, bounded so a chatty
# process cannot grow this without limit.
_TAIL_LINES = 20


class InstallManager:
    def __init__(self, config, library, store, rescan, spawn=None, hold=None):
        self._config = config
        self._library = library
        self._store = store
        self._rescan = rescan
        self._spawn = spawn or asyncio.create_subprocess_exec
        self._hold = hold
        self._queue: asyncio.Queue[str] = asyncio.Queue()
        self._current_job_id: str | None = None
        self._current_proc = None
        self._cancelled: set[str] = set()
        # Anything still "running" belongs to a previous process that is gone.
        interrupted = store.mark_running_jobs_interrupted()
        if interrupted:
            logger.warning("marked %d orphaned install job(s) interrupted", interrupted)

    # -- queries

    def status(self, job_id: str) -> InstallJob | None:
        return self._store.get_job(job_id)

    def all_jobs(self) -> list[InstallJob]:
        return self._store.list_jobs()

    def active_job_for_game(self, game_id: str) -> InstallJob | None:
        return self._store.active_job_for_game(game_id)

    def _find_game(self, game_id: str) -> Game | None:
        for game in self._library.snapshot():
            if game.id == game_id:
                return game
        return None

    # -- commands

    async def enqueue(self, game_id: str) -> InstallJob:
        game = self._find_game(game_id)
        if game is None:
            raise LookupError(f"unknown game: {game_id}")
        if game.state == "installed":
            raise ValueError(f"{game_id} is already installed")
        if self._store.active_job_for_game(game_id) is not None:
            raise ValueError(f"{game_id} already has an install in flight")
        if driver_for(game, self._config) is None:
            raise ValueError(f"{game_id} has no headless installer")

        job = InstallJob(
            job_id=uuid.uuid4().hex,
            game_id=game_id,
            state="queued",
            created_at=datetime.now(tz=UTC).isoformat(),
        )
        self._store.upsert_job(job)
        await self._queue.put(job.job_id)
        return job

    async def cancel(self, job_id: str) -> bool:
        job = self._store.get_job(job_id)
        if job is None or job.state not in ("queued", "downloading", "verifying"):
            return False
        # The helper only watches: Steam itself is doing the download, and has no
        # unattended way to stop one.
        if self._current_job_id == job_id and not job_cancellable(job):
            return False

        # Record the intent first. The worker consults this both before
        # starting a queued job and after its child exits, so a cancel racing
        # either boundary still lands.
        self._cancelled.add(job_id)
        if self._current_job_id == job_id and self._current_proc is not None:
            try:
                self._current_proc.kill()
            except ProcessLookupError:
                pass
        else:
            job.state = "cancelled"
            self._store.upsert_job(job)
        return True

    # -- worker

    async def run_forever(self) -> None:
        while True:
            job_id = await self._queue.get()
            try:
                await self._run_job(job_id)
            except Exception:
                logger.exception("install job %s crashed", job_id)
            finally:
                self._queue.task_done()

    async def drain(self) -> None:
        """Run queued jobs until none remain. Used by tests and by shutdown."""
        while not self._queue.empty():
            job_id = await self._queue.get()
            try:
                await self._run_job(job_id)
            except Exception:
                logger.exception("install job %s crashed", job_id)
            finally:
                self._queue.task_done()

    def _finish(self, job: InstallJob, state: str, reason: str | None = None) -> None:
        job.state = state
        job.reason = reason
        self._store.upsert_job(job)

    async def _run_job(self, job_id: str) -> None:
        job = self._store.get_job(job_id)
        if job is None:
            return
        if job_id in self._cancelled:
            self._cancelled.discard(job_id)
            self._finish(job, "cancelled")
            return

        game = self._find_game(job.game_id)
        driver = driver_for(game, self._config) if game else None
        if driver is None:
            self._finish(job, "failed", f"{job.game_id} is no longer installable")
            return

        job.state = "downloading"
        self._store.upsert_job(job)

        if self._hold is not None:
            self._hold.start()
        try:
            await self._run_driver(job, job_id, driver)
        finally:
            if self._hold is not None:
                await self._hold.stop()

    async def _run_driver(self, job: InstallJob, job_id: str, driver) -> None:
        tail: list[str] = []
        try:
            proc = await self._spawn(
                *driver.args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
        except OSError as exc:
            self._finish(job, "failed", f"could not start installer: {exc}")
            return

        self._current_job_id, self._current_proc = job_id, proc
        try:
            async for raw in proc.stdout:
                line = raw.decode(errors="replace").rstrip("\n")
                tail.append(line)
                del tail[:-_TAIL_LINES]
                progress = driver.parse(line)
                if progress:
                    job.state = progress.get("state", job.state)
                    job.percent = progress.get("percent", job.percent)
                    job.bytes_done = progress.get("bytes_done", job.bytes_done)
                    job.bytes_total = progress.get("bytes_total", job.bytes_total)
                    job.eta = progress.get("eta", job.eta)
                    self._store.upsert_job(job)
            code = await proc.wait()
        finally:
            self._current_job_id, self._current_proc = None, None

        if job_id in self._cancelled:
            self._cancelled.discard(job_id)
            self._finish(job, "cancelled")
            return

        if code == 0:
            # Before `done`: whoever sees the job finish should find the game
            # installed, with a launch entry, rather than racing the rescan.
            await asyncio.to_thread(self._rescan)
            self._finish(job, "done")
        else:
            self._finish(job, "failed", driver.classify_failure(code, "\n".join(tail)))
