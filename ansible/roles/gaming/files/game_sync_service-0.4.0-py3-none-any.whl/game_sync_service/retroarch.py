from __future__ import annotations

import re
from pathlib import Path

from game_sync_service.config import Config
from game_sync_service.models import Game

# system dir name -> (libretro core, accepted extensions)
SYSTEM_CORES: dict[str, tuple[str, set[str]]] = {
    "nes": ("nestopia", {".nes"}),
    "snes": ("snes9x", {".sfc", ".smc"}),
    "n64": ("mupen64plus_next", {".z64", ".n64", ".v64"}),
    "genesis": ("genesis_plus_gx", {".md", ".gen", ".smd", ".bin"}),
    "megadrive": ("genesis_plus_gx", {".md", ".gen", ".smd", ".bin"}),
    "mastersystem": ("genesis_plus_gx", {".sms"}),
    "gamegear": ("genesis_plus_gx", {".gg"}),
    "gb": ("mgba", {".gb", ".gbc"}),
    "gbc": ("mgba", {".gbc"}),
    "gba": ("mgba", {".gba"}),
    "nds": ("desmume", {".nds"}),
    "psx": ("beetle_psx_hw", {".cue", ".chd", ".pbp"}),
    "ps2": ("pcsx2", {".iso", ".chd"}),
    "psp": ("ppsspp", {".iso", ".cso"}),
    "gamecube": ("dolphin", {".iso", ".rvz", ".gcm"}),
    "gc": ("dolphin", {".iso", ".rvz", ".gcm"}),  # ES-DE's name for it
    "wii": ("dolphin", {".iso", ".rvz", ".wbfs"}),
}

_TAG_RE = re.compile(r"[\(\[][^\)\]]*[\)\]]")
# Lower is better. USA first for its 60 Hz releases; a file with no region tag
# could be anything, so it sits between those and the known 50 Hz ones.
_REGION_RANK = {"usa": 0, "u": 0, "world": 0, "w": 0, "europe": 2, "e": 2, "japan": 3, "j": 3}
_UNTAGGED_RANK = 1
_OTHER_REGION_RANK = 4
_NOT_A_RELEASE = re.compile(r"\b(beta|proto|prototype|demo|sample|hack|pirate|unl)\b|^b\d*$", re.I)


def clean_rom_name(stem: str) -> str:
    name = _TAG_RE.sub("", stem).replace("_", " ")
    return re.sub(r"\s+", " ", name).strip()


def _rom_preference(stem: str) -> tuple:
    """Sort key choosing which copy of a game stands for it; lowest wins."""
    tags = [t.strip() for tag in _TAG_RE.findall(stem) for t in tag[1:-1].split(",")]
    ranks = [_REGION_RANK[t.lower()] for t in tags if t.lower() in _REGION_RANK]
    region = min(ranks) if ranks else (_OTHER_REGION_RANK if tags else _UNTAGGED_RANK)
    # The filename last: it puts Disc 1 first, and keeps the choice stable.
    return (any(_NOT_A_RELEASE.search(t) for t in tags), region, stem)


def _slugify(text: str) -> str:
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]", "-", text.lower())).strip("-")


def scan_retroarch_games(config: Config) -> list[Game]:
    root = config.retroarch_rom_path
    if not config.retroarch_enabled or root is None or not root.is_dir():
        return []
    games: list[Game] = []
    for system_dir in sorted(root.iterdir()):
        entry = SYSTEM_CORES.get(system_dir.name)
        if not entry or not system_dir.is_dir():
            continue
        core, extensions = entry
        # By id, which regional copies and the discs of a game share.
        chosen: dict[str, tuple[str, Path]] = {}
        for rom in system_dir.iterdir():
            if rom.suffix.lower() not in extensions:
                continue
            name = clean_rom_name(rom.stem)
            game_id = f"retroarch-{system_dir.name}-{_slugify(name)}"
            held = chosen.get(game_id)
            if held is None or _rom_preference(rom.stem) < _rom_preference(held[1].stem):
                chosen[game_id] = (name, rom)
        for game_id, (name, rom) in sorted(chosen.items()):
            games.append(
                Game(
                    id=game_id,
                    name=name,
                    source="retroarch",
                    platform=system_dir.name,
                    state="installed",
                    emulator=core,
                    slug=_slugify(name),
                    rom_path=str(rom),
                )
            )
    return games
