"""Drive the Steam client already running in the gaming session.

Everything here was measured on the gaming VM (see the spike notes in
home-player/docs/superpowers/specs/2026-11-02-games-just-work-spikes.md), and
the odd parts have reasons:

- A launch's `AppId=` helper appears well before a Proton game does, so "started"
  comes from Steam's own log instead.
- A Proton game is not a child of Steam's reaper. What every game process does
  carry is `SteamAppId=<id>` in its environment.
- Never read `steam.pipe`: it blocks, and can swallow Steam's commands.
"""
from __future__ import annotations

import argparse
import os
import re
import shlex
import signal
import subprocess
import sys
import time
from pathlib import Path

from game_sync_service.config import load_config
from game_sync_service.steam_local import parse_acf
from game_sync_service.sunshine import stream_live

_DEFAULT_CONFIG = "/etc/game-sync/game-sync.conf"

# Up to 5 minutes from launch to running: a first launch compiles shaders.
START_TIMEOUT = 300.0
STEAM_READY_TIMEOUT = 180.0
# Proton hands off between processes while it starts and stops.
EXIT_SETTLE = 5.0
STOP_TIMEOUT = 25.0
INSTALL_START_TIMEOUT = 180.0

_WRAPPERS = (
    "reaper", "pressure-vessel", "steam-runtime", "pv-adverb", "bwrap", "proton",
    "wineserver", "python",
)
_FULLY_INSTALLED = 4


def _environ(pid_dir: Path) -> list[bytes]:
    return (pid_dir / "environ").read_bytes().split(b"\0")


def _cmdline(pid_dir: Path) -> str:
    return (pid_dir / "cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "replace")


def processes_with_env(entry: str) -> list[tuple[int, str]]:
    """Every process, other than this one, with `entry` in its environment."""
    wanted = entry.encode()
    found = []
    for pid_dir in Path("/proc").glob("[0-9]*"):
        pid = int(pid_dir.name)
        if pid == os.getpid():
            continue
        try:
            if wanted in _environ(pid_dir):
                found.append((pid, _cmdline(pid_dir)))
        except OSError:
            continue  # gone, or not ours
    return found


def _cmdline_contains(*needles: str) -> list[Path]:
    matches = []
    for pid_dir in Path("/proc").glob("[0-9]*"):
        if int(pid_dir.name) == os.getpid():
            continue
        try:
            cmdline = _cmdline(pid_dir)
        except OSError:
            continue
        if all(n in cmdline for n in needles):
            matches.append(pid_dir)
    return matches


def game_running(appid: str) -> bool:
    return bool(processes_with_env(f"SteamAppId={appid}"))


def any_game_running() -> bool:
    return bool(_cmdline_contains("reaper", "SteamLaunch"))


def steam_ready() -> bool:
    # Steam's UI runs several of these once it is up; one or two are only starting.
    return len(_cmdline_contains("steamwebhelper")) > 2


def _wait_until(predicate, timeout: float, poll: float) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(poll)
    return predicate()


def _is_wrapper(cmdline: str) -> bool:
    # The program itself, not its arguments: Proton is handed the game's path.
    program = cmdline.split(" ", 1)[0]
    return any(w in program for w in _WRAPPERS)


def stop_targets(processes: list[tuple[int, str]]) -> list[int]:
    """The processes to signal to end a game.

    Only the game itself: Proton's wrappers unwind on their own once it exits,
    and signalling them first can leave the game behind.
    """
    own = [(pid, cmd) for pid, cmd in processes if not _is_wrapper(cmd)]
    executables = [
        pid for pid, cmd in own
        if ".exe" in cmd.lower() and "\\windows\\" not in cmd.lower()
    ]
    return executables or [pid for pid, _ in own]


def stop_game(env_entry: str, timeout: float = STOP_TIMEOUT, poll: float = 0.5) -> bool:
    for pid in stop_targets(processes_with_env(env_entry)):
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            continue
    return _wait_until(lambda: not processes_with_env(env_entry), timeout, poll)


class _LogWatch:
    """Lines added to a log since this was created."""

    def __init__(self, path: Path):
        self._path = path
        try:
            self._offset = path.stat().st_size
        except OSError:
            self._offset = 0

    def seen(self, pattern: re.Pattern) -> bool:
        try:
            with self._path.open("rb") as f:
                f.seek(self._offset)
                text = f.read().decode("utf-8", "replace")
        except OSError:
            return False
        return bool(pattern.search(text))


def supervise(
    env_entry: str,
    start,
    started,
    start_timeout: float = START_TIMEOUT,
    settle: float = EXIT_SETTLE,
    poll: float = 1.0,
    tick=None,
) -> int:
    """Block for the life of a game, so Sunshine's stream lasts exactly as long.

    Ending the stream on SIGTERM (Moonlight's quit) ends the game too. A client
    merely disconnecting sends nothing, so reconnecting finds the game running.
    """

    def _on_term(_signum, _frame):
        stop_game(env_entry)
        sys.exit(0)

    signal.signal(signal.SIGTERM, _on_term)
    signal.signal(signal.SIGINT, _on_term)

    if not processes_with_env(env_entry):
        start()
        if not _wait_until(started, start_timeout, poll):
            print("game never started", file=sys.stderr)
            return 1

    quiet_since = None
    while True:
        if processes_with_env(env_entry):
            quiet_since = None
            if tick:
                tick()
        elif quiet_since is None:
            quiet_since = time.monotonic()
        elif time.monotonic() - quiet_since >= settle:
            return 0
        time.sleep(poll)


def launch(appid: str, config) -> int:
    if not _wait_until(steam_ready, STEAM_READY_TIMEOUT, 1.0):
        print("Steam is not running", file=sys.stderr)
        return 1
    log = _LogWatch(config.steam_root / "logs" / "content_log.txt")
    running = re.compile(rf"AppID {re.escape(appid)} state changed : .*App Running")

    def start() -> None:
        subprocess.run(
            shlex.split(config.steam_cmd) + [f"steam://rungameid/{appid}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

    return supervise(f"SteamAppId={appid}", start, lambda: log.seen(running))


def _display_env() -> dict[str, str]:
    """Steam's own display, which is the one inside gamescope."""
    env = dict(os.environ)
    for pid_dir in _cmdline_contains("ubuntu12_32/steam "):
        try:
            entries = _environ(pid_dir)
        except OSError:
            continue
        for entry in entries:
            for name in (b"DISPLAY=", b"XAUTHORITY="):
                if entry.startswith(name):
                    key, _, value = entry.decode("utf-8", "replace").partition("=")
                    env[key] = value
        if "DISPLAY" in env:
            break
    return env


def _manifest(config, appid: str) -> dict[str, str] | None:
    for library in config.steam_library_paths:
        path = Path(library) / "steamapps" / f"appmanifest_{appid}.acf"
        try:
            return parse_acf(path.read_text(errors="replace"))
        except OSError:
            continue
    return None


def _flags(manifest: dict[str, str]) -> int:
    value = manifest.get("StateFlags", "0")
    return int(value) if value.isdigit() else 0


def progress_line(manifest: dict[str, str]) -> str | None:
    done, total = manifest.get("BytesDownloaded", ""), manifest.get("BytesToDownload", "")
    if not (done.isdigit() and total.isdigit()) or int(total) == 0:
        return None
    return f"progress {100 * int(done) / int(total):.2f} {done} {total}"


def write_install_manifest(library: Path, appid: str, name: str) -> None:
    """Tell Steam a game needs installing, as it would record it itself."""
    installdir = re.sub(r"[^A-Za-z0-9 ._-]", "", name).strip(" .") or f"app{appid}"
    (Path(library) / "steamapps" / f"appmanifest_{appid}.acf").write_text(
        '"AppState"\n{\n'
        f'\t"appid"\t\t"{appid}"\n'
        '\t"Universe"\t\t"1"\n'
        f'\t"name"\t\t"{name.replace(chr(34), "")}"\n'
        '\t"StateFlags"\t\t"1026"\n'
        f'\t"installdir"\t\t"{installdir}"\n'
        '\t"LastUpdated"\t\t"0"\n\t"SizeOnDisk"\t\t"0"\n'
        '\t"BytesToDownload"\t\t"0"\n\t"BytesDownloaded"\t\t"0"\n}\n'
    )


def install(
    appid: str,
    name: str,
    config,
    busy=lambda: stream_live() or any_game_running(),
    poll: float = 2.0,
    start_timeout: float = INSTALL_START_TIMEOUT,
) -> int:
    """Have Steam install a game, printing progress for the install queue.

    Steam takes a "needs install" manifest when it starts, with no dialog, and
    restarting it costs about 20 seconds. That needs nobody using it, so this waits
    its turn. `steam://install` is no alternative: it asks for confirmation, and a
    blind key press lands on whatever has focus if the dialog isn't up yet.
    """
    while busy():
        time.sleep(poll)
    library = Path(config.steam_library_paths[0])
    write_install_manifest(library, appid, name)
    subprocess.run(shlex.split(config.steam_restart_cmd), check=False)

    log = _LogWatch(config.steam_root / "logs" / "content_log.txt")
    started = re.compile(rf"AppID {re.escape(appid)} update started")
    deadline = time.monotonic() + start_timeout
    begun = False
    while True:
        manifest = _manifest(config, appid)
        if manifest is None:
            print("The install was cancelled in Steam")
            return 1
        if _flags(manifest) == _FULLY_INSTALLED:
            return 0
        begun = begun or log.seen(started)
        if not begun and time.monotonic() > deadline:
            # Otherwise it sits in the library looking half installed.
            (library / "steamapps" / f"appmanifest_{appid}.acf").unlink(missing_ok=True)
            print("Steam did not start the install")
            return 1
        line = progress_line(manifest)
        if line:
            print(line, flush=True)
        time.sleep(poll)


def main() -> None:
    parser = argparse.ArgumentParser(prog="game-sync-steam")
    parser.add_argument("action", choices=["launch", "install"])
    parser.add_argument("appid")
    parser.add_argument("name", nargs="?", default="")
    args = parser.parse_args()
    config = load_config(os.environ.get("GAME_SYNC_CONFIG", _DEFAULT_CONFIG))
    if args.action == "launch":
        sys.exit(launch(args.appid, config))
    sys.exit(install(args.appid, args.name or args.appid, config))


if __name__ == "__main__":
    main()
