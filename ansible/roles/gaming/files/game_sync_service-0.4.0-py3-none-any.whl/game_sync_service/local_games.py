"""Classic PC games with no store: a folder copied in, described by a manifest.

Each lives at `<local_games_dir>/<slug>/game.toml`, and its folder name is its
identity. A folder without a manifest may still be copying, so it is not an error.
"""
from __future__ import annotations

import logging
import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path, PurePath

from game_sync_service.models import Game

logger = logging.getLogger(__name__)

MANIFEST = "game.toml"

# Goes into the command Sunshine runs, unquoted.
_SLUG = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")
_UMU_ID = re.compile(r"umu-[A-Za-z0-9_-]+")


@dataclass
class LocalGame:
    slug: str
    name: str
    folder: Path
    exe: str
    args: list[str] = field(default_factory=list)
    proton: str | None = None
    umu_id: str | None = None
    steam_appid: str | None = None
    env: dict[str, str] = field(default_factory=dict)
    installer: str | None = None

    @property
    def executable(self) -> Path:
        return self.folder / self.exe

    @property
    def installer_path(self) -> Path | None:
        return self.folder / self.installer if self.installer else None


def _text(data: dict, key: str) -> str | None:
    value = data.get(key)
    if value is None:
        return None
    if not isinstance(value, str) or not value:
        raise ValueError(f"{key} must be a non-empty string")
    return value


def _inside_folder(data: dict, key: str) -> str | None:
    value = _text(data, key)
    if value and (PurePath(value).is_absolute() or ".." in PurePath(value).parts):
        raise ValueError(f"{key} must be relative to the game's folder")
    return value


def load_manifest(folder: Path) -> LocalGame:
    """Raises ValueError or OSError if the manifest can't be used."""
    if not _SLUG.fullmatch(folder.name):
        raise ValueError("folder name can only use letters, digits, '.', '_' and '-'")
    data = tomllib.loads((folder / MANIFEST).read_text())
    name, exe = _text(data, "name"), _inside_folder(data, "exe")
    if not name or not exe:
        raise ValueError("name and exe are required")
    args = data.get("args", [])
    if not isinstance(args, list) or not all(isinstance(a, str) for a in args):
        raise ValueError("args must be a list of strings")
    env = data.get("env", {})
    if not isinstance(env, dict) or not all(isinstance(v, str) for v in env.values()):
        raise ValueError("env values must be strings")
    umu_id = _text(data, "umu_id")
    if umu_id and not _UMU_ID.fullmatch(umu_id):
        raise ValueError("umu_id must look like umu-<id>")
    steam_appid = data.get("steam_appid")
    if not isinstance(steam_appid, (int, str, type(None))) or isinstance(steam_appid, bool):
        raise ValueError("steam_appid must be a number")
    return LocalGame(
        slug=folder.name,
        name=name,
        folder=folder,
        exe=exe,
        args=args,
        proton=_text(data, "proton"),
        umu_id=umu_id,
        steam_appid=str(steam_appid) if steam_appid else None,
        env=env,
        installer=_inside_folder(data, "installer"),
    )


def load_game(config, slug: str) -> LocalGame:
    """One game by the name it was launched with, which came from a command line."""
    if not _SLUG.fullmatch(slug):
        raise ValueError("not a local game's name")
    return load_manifest(Path(config.local_games_dir) / slug)


def _to_game(local: LocalGame) -> Game:
    installed = local.executable.is_file()
    return Game(
        id=f"local-{local.slug}",
        name=local.name,
        source="local",
        platform="windows",
        state="installed" if installed else "not_installed",
        slug=local.slug,
        service_appid=local.slug,
        steam_appid=local.steam_appid,
        has_installer=local.installer is not None,
        # When it was added, for lack of anything better to sort by.
        installed_at=int((local.folder / MANIFEST).stat().st_mtime) if installed else None,
    )


def scan_local_games(config) -> list[Game]:
    root = Path(config.local_games_dir)
    if not root.is_dir():
        return []
    games = []
    for folder in sorted(root.iterdir()):
        if not (folder / MANIFEST).is_file():
            continue
        try:
            games.append(_to_game(load_manifest(folder)))
        except (OSError, ValueError) as exc:
            logger.warning("skipping local game %s: %s", folder.name, exc)
    return games
