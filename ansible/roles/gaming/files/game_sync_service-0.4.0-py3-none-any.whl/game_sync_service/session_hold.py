"""Keep the gaming VM up while an install runs.

gpu-manager stops an idle VM after its grace period, which would end a download
partway. Reporting a session for the length of the job prevents that.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging

import httpx

logger = logging.getLogger(__name__)

# gpu-manager's session TTL is three of these.
_HEARTBEAT_SECONDS = 60.0


class SessionHold:
    def __init__(self, client: httpx.AsyncClient, url: str, vm: str, stream_live,
                 interval: float = _HEARTBEAT_SECONDS):
        self._client = client
        self._url = f"{url.rstrip('/')}/v1/sessions/{vm}"
        self._stream_live = stream_live
        self._interval = interval
        self._task: asyncio.Task | None = None

    async def _beat(self) -> None:
        while True:
            try:
                await self._client.put(self._url, timeout=5)
            except httpx.HTTPError as exc:
                logger.warning("could not hold the session: %s", exc)
            await asyncio.sleep(self._interval)

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._beat())

    async def stop(self) -> None:
        if self._task is None:
            return
        self._task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self._task
        self._task = None
        # Without this the session decays to `unknown`, which never releases the
        # card. A live stream still owns it, and its own hook will end it.
        if self._stream_live():
            return
        try:
            await self._client.delete(self._url, timeout=5)
        except httpx.HTTPError as exc:
            logger.warning("could not release the session: %s", exc)
