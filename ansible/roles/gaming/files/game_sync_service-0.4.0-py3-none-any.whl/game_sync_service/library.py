from __future__ import annotations

import logging
from dataclasses import fields, replace

from game_sync_service.config import Config
from game_sync_service.legendary import scan_legendary
from game_sync_service.local_games import scan_local_games
from game_sync_service.lutris import read_lutris_games, read_lutris_service_games
from game_sync_service.models import Game
from game_sync_service.ports import scan_ports
from game_sync_service.profiles import load_profiles, recommended_profile
from game_sync_service.retroarch import scan_retroarch_games
from game_sync_service.showcase import load_pins, select_showcase
from game_sync_service.steam_local import scan_steam_local
from game_sync_service.sunshine import can_launch

logger = logging.getLogger(__name__)

# Merged field-wise; `id` is the identity and `state` has its own rule.
_MERGE_SKIP = {"id", "state"}
_EMPTY = (None, "", [], False)


def _assign_sunshine_names(games: list[Game]) -> None:
    taken: set[str] = set()
    for game in games:
        # Only what Sunshine can really launch, or Play would point at nothing.
        if game.state != "installed" or not can_launch(game):
            continue
        # By system for a ROM: one title can be on several, all from one source.
        suffix = game.platform if game.source == "retroarch" else game.source
        name = game.name if game.name not in taken else f"{game.name} ({suffix})"
        game.sunshine_app_name = name
        taken.add(name)


def merge_games(groups: list[list[Game]]) -> list[Game]:
    """Collapse records that describe the same game.

    Identity is `Game.id`, which every scanner builds as
    `{source}-{store_id}` — so a Lutris catalogue row, a Steam Web API row
    and an installed `.acf` for one title collide without any title matching.

    Groups are ordered highest-precedence first: the first non-empty value
    for a field wins. Install state is the exception and does not follow
    precedence at all — any scanner reporting `installed` wins, because that
    sighting comes from the filesystem and outranks what any index believes.
    """
    merged: dict[str, Game] = {}
    for group in groups:
        for game in group:
            existing = merged.get(game.id)
            if existing is None:
                merged[game.id] = replace(game)
                continue
            if game.state == "installed":
                existing.state = "installed"
            for f in fields(Game):
                if f.name in _MERGE_SKIP:
                    continue
                if getattr(existing, f.name) in _EMPTY:
                    value = getattr(game, f.name)
                    if value not in _EMPTY:
                        setattr(existing, f.name, value)
    return list(merged.values())


class Library:
    def __init__(self, config: Config, store=None):
        self._config = config
        self._store = store
        self._games: list[Game] = []
        # Refreshed asynchronously by the Steam Web API poller; scan() stays
        # synchronous so the pga.db file watcher can keep calling it directly.
        self._owned_cache: list[Game] = []
        self._legendary_cache: dict = {}

    def set_owned_cache(self, games: list[Game]) -> None:
        self._owned_cache = list(games)

    @staticmethod
    def _safe(label: str, fn, *args) -> list[Game]:
        """One scanner failing must never empty the library."""
        try:
            return fn(*args)
        except Exception:
            logger.exception("scanner %s failed; treating as empty", label)
            return []

    def _scan_legendary(self) -> list[Game]:
        return scan_legendary(self._config, cache=self._legendary_cache)

    def _mark_showcase(self, games: list[Game]) -> None:
        chosen = select_showcase(
            games,
            cap=self._config.retroarch_showcase_cap,
            pins=load_pins(self._config.data_dir / "showcase.toml"),
            last_played=self._store.last_played() if self._store else {},
            enrichments=self._store.get_all() if self._store else {},
        )
        for game in games:
            game.showcase = game.id in chosen

    def scan(self) -> list[Game]:
        groups = [
            # Filesystem first: it is the only source that knows what is
            # really on disk.
            self._safe("steam_local", scan_steam_local, self._config),
            self._safe("legendary", self._scan_legendary),
            self._safe("local", scan_local_games, self._config),
            self._safe("lutris", read_lutris_games, self._config),
            self._safe("retroarch", scan_retroarch_games, self._config),
            self._safe("ports", scan_ports, self._config),
            # Catalogue sources last: they fill in titles nothing else saw.
            self._safe("lutris_service", read_lutris_service_games, self._config),
            list(self._owned_cache),
        ]
        games = merge_games(groups)
        games.sort(key=lambda g: (g.installed_at is None, -(g.installed_at or 0), g.name))
        self._safe("showcase", self._mark_showcase, games)
        _assign_sunshine_names(games)
        profiles = load_profiles(self._config.game_profiles_path)
        for game in games:
            game.gpu_profile_recommended = recommended_profile(game, profiles)
        self._games = games
        return games

    def snapshot(self) -> list[Game]:
        return list(self._games)
