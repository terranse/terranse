"""Epic Games catalogue and install state, via the `legendary` CLI.

`legendary list` is the owned library, `legendary list-installed` the subset
on disk. Both are read with `--json` so we parse a contract rather than
scraping human output.

The `run` parameter is injected rather than reaching for `subprocess.run`
directly so tests can supply a fake without patching module globals.
"""
from __future__ import annotations

import json
import logging
import shlex
import subprocess
import time
from pathlib import Path

from game_sync_service.models import Game

logger = logging.getLogger(__name__)


# Reads Epic's servers, and the scan runs every minute.
_OWNED_TTL_SECONDS = 3600.0


def legendary_base(config) -> list[str]:
    """The legendary command, using the config directory that holds its login."""
    cmd = shlex.split(config.legendary_cmd)
    if getattr(config, "legendary_config_dir", ""):
        return ["env", f"LEGENDARY_CONFIG_PATH={config.legendary_config_dir}", *cmd]
    return cmd


def _list(config, args: list[str], run) -> list[dict]:
    cmd = legendary_base(config) + args + ["--json"]
    try:
        proc = run(cmd, capture_output=True, text=True, timeout=120)
        parsed = json.loads(proc.stdout)
    except (OSError, subprocess.SubprocessError, ValueError) as exc:
        logger.warning("legendary %s failed: %s", " ".join(args), exc)
        return []
    return parsed if isinstance(parsed, list) else []


def _owned(config, run, cache: dict | None, clock) -> list[dict]:
    if cache and cache["expires"] > clock():
        return cache["owned"]
    owned = _list(config, ["list"], run)
    if cache is not None and owned:
        cache.update(owned=owned, expires=clock() + _OWNED_TTL_SECONDS)
    return owned


def _installed_at(entry: dict) -> int | None:
    # Without this every Epic game sorts after every Steam game in the row.
    try:
        return int(Path(entry["install_path"]).stat().st_mtime)
    except (KeyError, TypeError, OSError):
        return None


def scan_legendary(config, run=subprocess.run, cache: dict | None = None, clock=time.monotonic) -> list[Game]:
    owned = _owned(config, run, cache, clock)
    if not owned:
        # Nothing owned (or legendary is absent/unauthenticated) — no point
        # paying for a second subprocess to ask what is installed.
        return []

    installed = {e.get("app_name"): e for e in _list(config, ["list-installed"], run)}

    games: list[Game] = []
    for entry in owned:
        app_name = entry.get("app_name")
        if not app_name:
            continue
        games.append(
            Game(
                id=f"epic-{app_name}",
                name=entry.get("app_title") or app_name,
                source="epic",
                platform="windows",
                state="installed" if app_name in installed else "not_installed",
                service_appid=app_name,
                installed_at=_installed_at(installed[app_name]) if app_name in installed else None,
            )
        )
    return games
