from __future__ import annotations

import argparse
import asyncio
import contextlib
import logging

import httpx
import uvicorn

from game_sync_service.api import create_app
from game_sync_service.config import Config, load_config
from game_sync_service.epic_client import epic_game_running
from game_sync_service.igdb import IGDBClient
from game_sync_service.install import InstallManager
from game_sync_service.library import Library
from game_sync_service.pipeline import EnrichmentPipeline
from game_sync_service.sgdb import SGDBClient
from game_sync_service.steam_owned import fetch_steam_owned
from game_sync_service.store import MetadataStore
from game_sync_service.session_hold import SessionHold
from game_sync_service.steam_client import any_game_running
from game_sync_service.sunshine import SunshineReloader, stream_live, sync_sunshine_apps
from game_sync_service.watcher import DbWatcher

logger = logging.getLogger(__name__)

REFRESH_SECONDS = 60.0
# The owned catalogue reads the Steam Web API, so only hourly.
OWNED_REFRESH_TICKS = 60


def build_app(config: Config):
    store = MetadataStore(config.data_dir / "metadata.db")
    library = Library(config)
    igdb = (
        IGDBClient(config.igdb_client_id, config.igdb_client_secret, store)
        if config.igdb_enabled
        else None
    )
    sgdb = SGDBClient(config.steamgriddb_api_key) if config.sgdb_enabled else None
    pipeline = EnrichmentPipeline(config, store, igdb, sgdb)
    background_tasks: set[asyncio.Task] = set()
    steam_client = httpx.AsyncClient() if config.steam_owned_enabled else None

    busy = lambda: stream_live() or any_game_running() or epic_game_running(config)
    reloader = SunshineReloader(config, busy)

    def scan_and_sync() -> list:
        games = library.scan()
        if sync_sunshine_apps(games, config):
            reloader.mark()
        return games

    def rescan_sync() -> None:
        """Synchronous rescan, run off the event loop by the install manager."""
        try:
            scan_and_sync()
        except Exception:
            logger.exception("Library scan after install failed")

    hold_client = httpx.AsyncClient() if config.gpu_manager_api_url else None
    hold = (
        SessionHold(hold_client, config.gpu_manager_api_url, config.gpu_manager_vm_name, stream_live)
        if hold_client is not None
        else None
    )

    installs = (
        InstallManager(config, library, store, rescan_sync, hold=hold)
        if config.install_enabled
        else None
    )

    async def refresh_owned() -> None:
        """Refresh the owned-Steam catalogue.

        Kept out of scan() so the file watcher's synchronous path never blocks
        on the network; scan() merges whatever this last left behind.
        """
        if steam_client is None:
            return
        try:
            owned = await fetch_steam_owned(config, steam_client)
        except Exception:
            logger.exception("Steam owned-games refresh failed")
            return
        if owned:
            library.set_owned_cache(owned)
            logger.info("Steam catalogue: %d owned title(s)", len(owned))

    async def rescan() -> None:
        try:
            games = await asyncio.to_thread(scan_and_sync)
        except Exception:
            logger.exception("Library scan failed")
            return
        logger.info("Scanned %d game(s)", len(games))
        task = asyncio.create_task(pipeline.enrich_library(games))
        background_tasks.add(task)
        task.add_done_callback(background_tasks.discard)

    async def refresh_forever() -> None:
        """Catch what nothing announces: installs and updates made in Steam itself."""
        ticks = 0
        while True:
            await asyncio.sleep(REFRESH_SECONDS)
            ticks += 1
            if ticks % OWNED_REFRESH_TICKS == 0:
                await refresh_owned()
            try:
                games = await asyncio.to_thread(scan_and_sync)
                await asyncio.to_thread(reloader.tick)
            except Exception:
                logger.exception("Periodic refresh failed")
                continue
            task = asyncio.create_task(pipeline.enrich_library(games))
            background_tasks.add(task)
            task.add_done_callback(background_tasks.discard)

    @contextlib.asynccontextmanager
    async def lifespan(app):
        loop = asyncio.get_running_loop()
        # Catalogue first, so the very first scan already includes owned games.
        await refresh_owned()
        await rescan()
        if installs is not None:
            worker = asyncio.create_task(installs.run_forever())
            background_tasks.add(worker)
        background_tasks.add(asyncio.create_task(refresh_forever()))
        watcher = DbWatcher(
            config.lutris_db_path,
            lambda: asyncio.run_coroutine_threadsafe(rescan(), loop),
        )
        if config.lutris_db_path.parent.is_dir():
            watcher.start()
            started = True
        else:
            logger.warning("Lutris db dir missing, watcher disabled")
            started = False
        yield
        if started:
            watcher.stop()
        for task in list(background_tasks):
            task.cancel()
        for client in (igdb, sgdb):
            if client:
                await client.aclose()
        if steam_client is not None:
            await steam_client.aclose()
        if hold_client is not None:
            await hold_client.aclose()
        store.close()

    app = create_app(config, library, store, installs=installs)
    app.router.lifespan_context = lifespan
    return app


def configure_logging() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    # One line per upstream call, each with its full URL.
    logging.getLogger("httpx").setLevel(logging.WARNING)


def main() -> None:
    parser = argparse.ArgumentParser(prog="game-sync-service")
    parser.add_argument("--config", required=True, help="Path to game-sync.conf")
    args = parser.parse_args()
    configure_logging()
    config = load_config(args.config)
    uvicorn.run(build_app(config), host="0.0.0.0", port=config.port)


if __name__ == "__main__":
    main()
