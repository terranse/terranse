"""Launch Epic games with legendary, umu-launcher and a pinned GE-Proton."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from game_sync_service.config import load_config
from game_sync_service.legendary import legendary_base
from game_sync_service.steam_client import (
    _DEFAULT_CONFIG,
    _display_env,
    processes_with_env,
    supervise,
)


def prefix_for(config, app_name: str) -> Path:
    return Path(config.epic_prefix_dir) / app_name


def epic_game_running(config) -> bool:
    return bool(config.epic_proton_dir) and bool(
        processes_with_env(f"PROTONPATH={config.epic_proton_dir}")
    )


def launch_command(config, app_name: str) -> list[str]:
    return legendary_base(config) + ["launch", app_name, "--no-wine", "--wrapper", "umu-run"]


def launch_env(config, app_name: str, base: dict[str, str]) -> dict[str, str]:
    env = dict(base)
    # Inside gamescope, not beside it: with sway's socket visible the game would
    # open as a sway window instead.
    env.pop("WAYLAND_DISPLAY", None)
    env.update(
        WINEPREFIX=str(prefix_for(config, app_name)),
        PROTONPATH=config.epic_proton_dir,
        STORE="egs",
        GAMEID="umu-0",
    )
    return env


def launch(app_name: str, config) -> int:
    prefix = prefix_for(config, app_name)
    prefix.mkdir(parents=True, exist_ok=True)
    env_entry = f"WINEPREFIX={prefix}"

    def start() -> None:
        # Returns at once; the game keeps running under the wrapper.
        subprocess.run(
            launch_command(config, app_name),
            env=launch_env(config, app_name, _display_env()),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

    return supervise(env_entry, start, lambda: bool(processes_with_env(env_entry)))


def main() -> None:
    parser = argparse.ArgumentParser(prog="game-sync-epic")
    parser.add_argument("action", choices=["launch"])
    parser.add_argument("app_name")
    args = parser.parse_args()
    config = load_config(os.environ.get("GAME_SYNC_CONFIG", _DEFAULT_CONFIG))
    sys.exit(launch(args.app_name, config))


if __name__ == "__main__":
    main()
