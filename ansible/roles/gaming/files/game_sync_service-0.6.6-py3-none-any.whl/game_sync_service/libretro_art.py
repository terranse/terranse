"""Box art for retro games from the keyless libretro thumbnail collection.

The collection names covers after No-Intro titles ("Legend of Zelda, The - The
Minish Cap (USA).png", "Pokemon - Blue Version (USA, Europe) (SGB
Enhanced).png"), which ROM files rarely match letter for letter, and its server
is case-sensitive. So each system's file list is read once and the ROM's name is
matched against it, rather than guessing file names.
"""
from __future__ import annotations

import asyncio
import difflib
import html
import logging
import os
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote, unquote

import httpx

from game_sync_service.models import Game

logger = logging.getLogger(__name__)

BASE = "https://thumbnails.libretro.com"

LIBRETRO_SYSTEMS: dict[str, str] = {
    "nes": "Nintendo - Nintendo Entertainment System",
    "snes": "Nintendo - Super Nintendo Entertainment System",
    "n64": "Nintendo - Nintendo 64",
    "genesis": "Sega - Mega Drive - Genesis",
    "megadrive": "Sega - Mega Drive - Genesis",
    "mastersystem": "Sega - Master System - Mark III",
    "gamegear": "Sega - Game Gear",
    "gb": "Nintendo - Game Boy",
    "gbc": "Nintendo - Game Boy Color",
    "gba": "Nintendo - Game Boy Advance",
    "nds": "Nintendo - Nintendo DS",
    "psx": "Sony - PlayStation",
    "ps2": "Sony - PlayStation 2",
    "psp": "Sony - PlayStation Portable",
    "gamecube": "Nintendo - GameCube",
    "gc": "Nintendo - GameCube",
    "wii": "Nintendo - Wii",
}

# Where else a game may be filed: dual-mode Game Boy carts are listed under
# Game Boy Color only ("Pokemon Pinball (...) (GB Compatible)").
SIBLINGS: dict[str, tuple[str, ...]] = {"gb": ("gbc",), "gbc": ("gb",)}

_TAGS = re.compile(r"\([^)]*\)|\[[^\]]*\]")
_DROP = {"the", "and"}
_ALIASES = {"bros": "brothers"}
# GoodTools-style one-letter regions, as in "(E)" or "(U)".
_REGION_LETTERS = {"u": "usa", "e": "europe", "j": "japan", "w": "world"}
_REGION_ORDER = ("usa", "europe", "world", "japan")
_NOT_A_RELEASE = re.compile(
    r"\b(beta|demo|proto|prototype|debug|kiosk|sample|pirate|unl|hack|virtual console|gamecube|overdump)\b",
    re.IGNORECASE,
)


class LibretroUnavailable(Exception):
    """The art host failed (network error or 5xx), as opposed to having no match."""


def title_tokens(name: str) -> tuple[str, ...]:
    """A title reduced to the words that identify it: no tags, accents, case or punctuation."""
    name = _TAGS.sub(" ", name)
    name = unicodedata.normalize("NFKD", name)
    name = "".join(c for c in name if not unicodedata.combining(c)).lower()
    name = name.replace("'", "")
    words = re.sub(r"[^a-z0-9]+", " ", name).split()
    return tuple(_ALIASES.get(w, w) for w in words if w not in _DROP)


def _tags(name: str) -> list[str]:
    return [t.strip().lower() for g in _TAGS.findall(name) for t in g[1:-1].split(",")]


@dataclass(frozen=True)
class _Entry:
    file: str
    tokens: tuple[str, ...]
    tags: tuple[str, ...]


def _entries(files: list[str]) -> list[_Entry]:
    return [_Entry(f, title_tokens(f[: -len(".png")]), tuple(_tags(f))) for f in files]


def _preference(entry: _Entry, regions: list[str]) -> tuple:
    """Lower is better: a real release, then the ROM's own region, then the common ones."""
    order = regions + [r for r in _REGION_ORDER if r not in regions]
    ranks = [order.index(t) for t in entry.tags if t in order]
    return (
        bool(_NOT_A_RELEASE.search(" ".join(entry.tags))),
        min(ranks) if ranks else len(order),
        len(entry.file),
        entry.file,
    )


def _fewest_extra(entries: list[_Entry], have: set[str]) -> list[_Entry]:
    if not entries:
        return []
    fewest = min(len(set(e.tokens) - have) for e in entries)
    return [e for e in entries if len(set(e.tokens) - have) == fewest]


def best_match(files: list[str], rom_stem: str) -> str | None:
    """The cover file in `files` that names the game in `rom_stem`, or None.

    In order: the same words; the same letters once spaces are gone; every
    ROM word plus at most two ("Pokemon Blue" in "Pokemon - Blue Version");
    the ROM's words followed by a subtitle ("Pokemon - Yellow Version -
    Special Pikachu Edition"); the cover's words with one stray ROM word
    ("Legend of Zelda 2 - Majora's Mask"), for titles of three words or more;
    and a spelling one letter off ("Tetris Sphere" for "Tetrisphere"). Within
    a tier, a real release in the ROM's own region wins.
    """
    want = title_tokens(rom_stem)
    if not want:
        return None
    regions = [_REGION_LETTERS.get(t, t) for t in _tags(rom_stem)]
    entries = _entries(files)
    joined = "".join(want)
    have = set(want)

    tiers = [
        [e for e in entries if e.tokens == want],
        [e for e in entries if "".join(e.tokens) == joined],
    ]
    # Below here a title of one word is too little to go on ("Tetris"), and a
    # number the ROM does not have is a sequel, not the same game.
    if len(want) < 2:
        return _pick(tiers, regions)

    def extra_numbers(e: _Entry) -> bool:
        return any(t.isdigit() and t not in have for t in e.tokens)

    tiers.append(_fewest_extra([
        e for e in entries
        if have < set(e.tokens) and len(set(e.tokens) - have) <= 2 and not extra_numbers(e)
    ], have))
    # A subtitle the ROM leaves off.
    tiers.append(_fewest_extra([
        e for e in entries
        if e.tokens[: len(want)] == want and len(e.tokens) > len(want) and not extra_numbers(e)
    ], have))
    tiers.append([
        e for e in entries
        if len(e.tokens) >= 3 and set(e.tokens) < have and len(have - set(e.tokens)) == 1
        and difflib.SequenceMatcher(None, " ".join(e.tokens), " ".join(want)).ratio() >= 0.85
    ])
    # One letter off once spaces are gone ("Tetris Sphere", "Tetrisphere"),
    # with the same numbers, so "Mario Party 3" never takes "Mario Party 2".
    digits = [t for t in want if t.isdigit()]
    tiers.append([
        e for e in entries
        if [t for t in e.tokens if t.isdigit()] == digits and len(joined) >= 8
        and difflib.SequenceMatcher(None, "".join(e.tokens), joined).ratio() >= 0.93
    ])
    return _pick(tiers, regions)


def _pick(tiers: list[list[_Entry]], regions: list[str]) -> str | None:
    for tier in tiers:
        if tier:
            return min(tier, key=lambda e: _preference(e, regions)).file
    return None


class LibretroArt:
    def __init__(self, http: httpx.AsyncClient | None = None):
        self._http = http or httpx.AsyncClient(timeout=60, follow_redirects=True)
        self._lists: dict[str, list[str]] = {}
        self._lock = asyncio.Lock()

    async def aclose(self) -> None:
        await self._http.aclose()

    async def fetch_cover(self, game: Game, dest: Path) -> bool:
        """True if a cover was saved, False on a true miss; raises LibretroUnavailable on errors."""
        platform = (game.platform or "").lower()
        if platform not in LIBRETRO_SYSTEMS or not game.rom_path:
            return False
        stem = Path(game.rom_path).stem
        for p in (platform, *SIBLINGS.get(platform, ())):
            system = LIBRETRO_SYSTEMS[p]
            try:
                files = await self._files(system)
                found = best_match(files, stem)
                if found and await self._download(self._url(system, found), dest):
                    return True
            except LibretroUnavailable:
                raise
            except Exception as exc:
                raise LibretroUnavailable(str(exc)) from exc
        return False

    @staticmethod
    def _url(system: str, file: str) -> str:
        return f"{BASE}/{quote(system, safe='')}/Named_Boxarts/{quote(file, safe='')}"

    async def _files(self, system: str) -> list[str]:
        """The system's cover file names, read once per process."""
        async with self._lock:
            if system not in self._lists:
                url = f"{BASE}/{quote(system, safe='')}/Named_Boxarts/"
                resp = await self._http.get(url)
                if resp.status_code == 404:
                    files: list[str] = []
                else:
                    resp.raise_for_status()
                    files = sorted({
                        unquote(html.unescape(h)) for h in re.findall(r'href="([^"?/]+\.png)"', resp.text)
                    })
                logger.info("libretro: %d cover(s) listed for %s", len(files), system)
                self._lists[system] = files
            return self._lists[system]

    async def _download(self, url: str, dest: Path) -> bool:
        tmp = dest.with_suffix(dest.suffix + ".part")
        try:
            async with self._http.stream("GET", url) as resp:
                if resp.status_code == 404:
                    return False
                resp.raise_for_status()
                dest.parent.mkdir(parents=True, exist_ok=True)
                with open(tmp, "wb") as f:
                    async for chunk in resp.aiter_bytes():
                        f.write(chunk)
            os.replace(tmp, dest)
            return True
        except BaseException:
            tmp.unlink(missing_ok=True)
            raise
