"""What the TV is showing of a game, for Home Player to follow.

A launcher (`supervise` in steam_client) runs for the life of a game, apart from
the service, so it records the game's phase in a small file the service serves:

- `starting` while the game launches,
- `on_screen` once gamescope shows it,
- `ended` the moment its last process is gone, before the settle wait that keeps
  the stream open across Proton's hand-offs.

The file also names the launcher's process, so a launcher that died without
saying `ended` (a crash, a reboot) leaves nothing that looks like a live game.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

FILENAME = "playing.json"
STARTING, ON_SCREEN, ENDED = "starting", "on_screen", "ended"
IDLE = {"phase": "idle"}
_FOCUSED = "GAMESCOPE_FOCUSED_APP_GFX"
# How long a game game-sync tagged itself may run before it counts as showing
# without gamescope saying so. An emulator or old game is up in a second or two.
TAGGED_FALLBACK = 5.0


def playing_path(config) -> Path:
    return Path(config.data_dir) / FILENAME


def _write(path: Path, content: str) -> None:
    """Whole or not at all, and readable by the service whoever wrote it."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(content)
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    except BaseException:
        os.unlink(tmp)
        raise


def _proc_start(pid: int) -> str | None:
    """When a process started, in clock ticks since boot: a pid alone can be reused."""
    try:
        stat = Path(f"/proc/{pid}/stat").read_text()
    except OSError:
        return None
    # The name can hold spaces and brackets; the fields after it can't.
    fields = stat.rpartition(")")[2].split()
    return fields[19] if len(fields) > 19 else None


def _read_root(env: dict[str, str], name: str) -> str:
    try:
        return subprocess.run(
            ["xprop", "-root", name],
            env=env, capture_output=True, text=True, timeout=2, check=False,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def focused_app(env: dict[str, str]) -> int | None:
    """The app id gamescope has focused, on the display `env` names.

    xprop prints `GAMESCOPE_FOCUSED_APP_GFX(CARDINAL) = 769`; 769 is Steam itself.
    """
    match = re.search(r"=\s*(\d+)", _read_root(env, _FOCUSED))
    return int(match[1]) if match else None


def gamescope_shows(app_id: int, env: dict[str, str]):
    """An on-screen check: gamescope has focused this app id."""
    return lambda: focused_app(env) == app_id


def gamescope_or_after(app_id: int, env: dict[str, str], delay: float = TAGGED_FALLBACK):
    """Gamescope's focus, or `delay` seconds of the game running, whichever is first.

    For games whose id game-sync gave them itself (retro, local): they are tagged
    with it, so focus normally names them, but a window the tagging misses must not
    leave the TV waiting on a game that is already showing.
    """
    first: list[float] = []

    def check() -> bool:
        if not first:
            first.append(time.monotonic())
        if time.monotonic() - first[0] >= delay:
            return True
        return focused_app(env) == app_id

    return check


class NowPlaying:
    """The phase of one game, written to the file whenever it changes."""

    def __init__(self, path: Path, game_id: str, on_screen=lambda: False):
        self._path = Path(path)
        self.game_id = game_id
        self._on_screen = on_screen
        self.phase: str | None = None
        self._before_end = STARTING

    def _set(self, phase: str) -> None:
        if phase == self.phase:
            return
        self.phase = phase
        pid = os.getpid()
        record = {
            "game_id": self.game_id,
            "phase": phase,
            "since": time.time(),
            "pid": pid,
            "pid_start": _proc_start(pid),
        }
        try:
            _write(self._path, json.dumps(record))
        except OSError as exc:
            # The TV falls back to its own timing; the game matters more.
            print(f"could not record {self.game_id} as {phase}: {exc}", file=sys.stderr)

    def starting(self) -> None:
        self._set(STARTING)

    def running(self) -> None:
        """A tick with the game's processes present."""
        if self.phase == ON_SCREEN:
            return
        if self.phase == ENDED and self._before_end == ON_SCREEN:
            # Back within the settle wait: a hand-off, not an exit.
            self._set(ON_SCREEN)
            return
        self._set(ON_SCREEN if self._on_screen() else STARTING)

    def ended(self) -> None:
        if self.phase != ENDED:
            self._before_end = self.phase or STARTING
        self._set(ENDED)


class Untracked:
    """For a supervised launch nobody follows: records nothing."""

    def starting(self) -> None: ...

    def running(self) -> None: ...

    def ended(self) -> None: ...


def read_playing(path: Path) -> dict:
    """The file's content, or idle when there's no game to speak of."""
    try:
        record = json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return dict(IDLE)
    if not isinstance(record, dict) or record.get("phase") not in (STARTING, ON_SCREEN, ENDED):
        return dict(IDLE)
    if record["phase"] != ENDED:
        # A launcher that died mid-game (a crash, a reboot) never wrote `ended`.
        # Same pid and same start time means the one that wrote this is still
        # there; the start time is what tells a reused pid after a reboot apart.
        pid = record.get("pid")
        start = _proc_start(pid) if isinstance(pid, int) else None
        if start is None or start != record.get("pid_start"):
            return dict(IDLE)
    return {key: record.get(key) for key in ("game_id", "phase", "since")}
