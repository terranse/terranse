"""Per-store install drivers.

Each driver is a command to run, a parser for its progress output, and a way
to turn a non-zero exit into something a person reading a TV screen can act
on. Only stores with a real headless installer get one; a game with no driver
is simply not offered as installable, which is better than an Install button
that always fails.
"""
from __future__ import annotations

import shlex
from dataclasses import dataclass
from typing import Callable

from game_sync_service.models import Game
from game_sync_service.progress import parse_legendary, parse_steamcmd

_MAX_TAIL = 300

# steamcmd reports auth trouble several different ways depending on whether the
# cached token is stale, revoked, or rate-limited. They all need the same fix.
_STEAM_AUTH_MARKERS = (
    "invalid password",
    "failed login",
    "login failure",
    "two-factor",
    "twofactor",
    "rate limit exceeded",
    "account logon denied",
)

STEAM_AUTH_REASON = (
    "Steam login expired — reseed the steamcmd token on the worker "
    "(run `steamcmd +login <user>` once and enter the Steam Guard code)"
)

EPIC_AUTH_REASON = "Epic login expired — run `legendary auth` on the worker"


@dataclass
class Driver:
    args: list[str]
    parse: Callable[[str], dict | None]
    classify_failure: Callable[[int, str], str]


def build_steam_args(config, appid: str, install_dir: str) -> list[str]:
    """The steamcmd invocation for one app.

    ForcePlatformType MUST come before app_update. Most of this library is
    Windows-under-Proton with no Linux depot at all, and without the flag
    steamcmd quietly fetches the wrong depot or fails.

    No password is ever passed: the only credential is the Guard refresh
    token cached on disk, which keeps secrets out of ps output and logs.
    """
    return (
        shlex.split(config.steamcmd_cmd)
        + [
            "+@sSteamCmdForcePlatformType", "windows",
            "+force_install_dir", install_dir,
            "+login", config.steam_username,
            "+app_update", appid, "validate",
            "+quit",
        ]
    )


def build_legendary_args(config, app_name: str) -> list[str]:
    return shlex.split(config.legendary_cmd) + ["install", app_name, "-y"]


def _tail(text: str) -> str:
    return text.strip()[-_MAX_TAIL:]


def _steam_failure(code: int, tail: str) -> str:
    lowered = tail.lower()
    if any(marker in lowered for marker in _STEAM_AUTH_MARKERS):
        return STEAM_AUTH_REASON
    return f"steamcmd exited {code}: {_tail(tail)}"


def _legendary_failure(code: int, tail: str) -> str:
    lowered = tail.lower()
    if "login" in lowered and ("fail" in lowered or "auth" in lowered):
        return EPIC_AUTH_REASON
    return f"legendary exited {code}: {_tail(tail)}"


def driver_for(game: Game, config) -> Driver | None:
    if game.source == "steam":
        # Every one of these is required for a non-interactive install; without
        # any of them the game is not installable and must not be offered.
        if not (game.service_appid and config.steam_username and config.steam_library_paths):
            return None
        install_dir = str(config.steam_library_paths[0])
        return Driver(
            build_steam_args(config, game.service_appid, install_dir),
            parse_steamcmd,
            _steam_failure,
        )

    if game.source == "epic" and game.service_appid:
        return Driver(
            build_legendary_args(config, game.service_appid),
            parse_legendary,
            _legendary_failure,
        )

    return None
