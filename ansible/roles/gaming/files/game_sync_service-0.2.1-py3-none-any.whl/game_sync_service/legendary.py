"""Epic Games catalogue and install state, via the `legendary` CLI.

`legendary list` is the owned library, `legendary list-installed` the subset
on disk. Both are read with `--json` so we parse a contract rather than
scraping human output.

The `run` parameter is injected rather than reaching for `subprocess.run`
directly so tests can supply a fake without patching module globals.
"""
from __future__ import annotations

import json
import logging
import shlex
import subprocess

from game_sync_service.models import Game

logger = logging.getLogger(__name__)


def _list(config, args: list[str], run) -> list[dict]:
    cmd = shlex.split(config.legendary_cmd) + args + ["--json"]
    try:
        proc = run(cmd, capture_output=True, text=True, timeout=120)
        parsed = json.loads(proc.stdout)
    except (OSError, subprocess.SubprocessError, ValueError) as exc:
        logger.warning("legendary %s failed: %s", " ".join(args), exc)
        return []
    return parsed if isinstance(parsed, list) else []


def scan_legendary(config, run=subprocess.run) -> list[Game]:
    owned = _list(config, ["list"], run)
    if not owned:
        # Nothing owned (or legendary is absent/unauthenticated) — no point
        # paying for a second subprocess to ask what is installed.
        return []

    installed_ids = {e.get("app_name") for e in _list(config, ["list-installed"], run)}

    games: list[Game] = []
    for entry in owned:
        app_name = entry.get("app_name")
        if not app_name:
            continue
        games.append(
            Game(
                id=f"epic-{app_name}",
                name=entry.get("app_title") or app_name,
                source="epic",
                platform="windows",
                state="installed" if app_name in installed_ids else "not_installed",
                service_appid=app_name,
            )
        )
    return games
