"""Normalize installer stdout into progress facts.

Both `steamcmd` and `legendary` print unversioned human-readable output, so
this is the part of the install path most likely to break on an upstream
upgrade. Every parser therefore returns `None` for anything it does not
recognize and never raises: unparseable output degrades the UI to "running,
percentage unknown" instead of killing an install that is working fine.
"""
from __future__ import annotations

import re

# steamcmd:
#  " Update state (0x61) downloading, progress: 42.15 (5368709120 / 12884901888)"
_STEAM = re.compile(
    r"Update state \(0x[0-9a-fA-F]+\)\s*(?P<what>[a-zA-Z ]+?),\s*progress:\s*"
    r"(?P<pct>\d+(?:\.\d+)?)\s*\(\s*(?P<done>\d+)\s*/\s*(?P<total>\d+)\s*\)"
)

# legendary:
#  "[DLManager] INFO: = Progress: 42.10% (1234/2930), Running for …, ETA: 00:02:00"
_LEGENDARY = re.compile(r"Progress:\s*(?P<pct>\d+(?:\.\d+)?)\s*%")
_LEGENDARY_ETA = re.compile(r"ETA:\s*(?P<eta>\d{1,2}:\d{2}(?::\d{2})?)")


def parse_steamcmd(line: str) -> dict | None:
    match = _STEAM.search(line)
    if not match:
        return None
    # steamcmd reports several phases under one line shape; only the
    # verification ones are worth distinguishing to the user.
    what = match.group("what").strip().lower()
    state = "verifying" if "verif" in what else "downloading"
    return {
        "state": state,
        "percent": float(match.group("pct")),
        "bytes_done": int(match.group("done")),
        "bytes_total": int(match.group("total")),
    }


def parse_legendary(line: str) -> dict | None:
    match = _LEGENDARY.search(line)
    if not match:
        return None
    out: dict = {"state": "downloading", "percent": float(match.group("pct"))}
    eta = _LEGENDARY_ETA.search(line)
    if eta:
        out["eta"] = eta.group("eta")
    return out
